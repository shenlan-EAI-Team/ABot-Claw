#!/usr/bin/env python3
import argparse
import base64
import hashlib
import json
import re
import sys
import urllib.request
from pathlib import Path
from typing import Any, Dict, List

import requests


DEFAULT_API_BASE = "http://localhost:8001"
DEFAULT_IMAGE_URL = f"{DEFAULT_API_BASE}/camera/rgb.jpg"
DEFAULT_CONFIG_PATH = "~/.openclaw/openclaw.json"
DEFAULT_STATE_PATH = "~/.openclaw/workspace/memory/g1_navigation_state.json"
DEFAULT_MAX_ACTIONS = 4
DEFAULT_TURN_ANGLE_DEG = 30
DEFAULT_FORWARD_SPEED_MPS = 0.15
DEFAULT_FORWARD_DURATION_S = 1.0
DEFAULT_LOST_THRESHOLD = 2
DEFAULT_REPEAT_PLAN_THRESHOLD = 2

ALLOWED_ACTIONS = {
    "turn_left_30",
    "turn_right_30",
    "forward_015m",
    "stop",
}


def load_openclaw_config(config_path: str) -> dict:
    path = Path(config_path).expanduser()
    return json.loads(path.read_text())


def resolve_moonshot_settings(config: dict) -> tuple[str, str, str]:
    provider = config["models"]["providers"]["moonshot"]
    base_url = str(provider["baseUrl"]).rstrip("/")
    api_key = str(provider["apiKey"])
    primary_model = str(config["agents"]["defaults"]["model"]["primary"])
    model = primary_model.split("/", 1)[1] if "/" in primary_model else primary_model
    return base_url, api_key, model


def resolve_state_path(state_path: str) -> Path:
    path = Path(state_path).expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def load_navigation_state(state_path: str) -> Dict[str, Any]:
    path = resolve_state_path(state_path)
    if not path.exists():
        raise RuntimeError("没有待继续的导航任务")
    return json.loads(path.read_text())


def save_navigation_state(state_path: str, state: Dict[str, Any]) -> None:
    path = resolve_state_path(state_path)
    path.write_text(json.dumps(state, ensure_ascii=False, indent=2))


def clear_navigation_state(state_path: str) -> None:
    path = resolve_state_path(state_path)
    if path.exists():
        path.unlink()


def fetch_image(image_url: str) -> bytes:
    with urllib.request.urlopen(image_url, timeout=15) as resp:
        return resp.read()


def image_signature(image_bytes: bytes) -> str:
    return hashlib.sha256(image_bytes).hexdigest()[:16]


def build_navigation_prompt(target: str, max_actions: int) -> str:
    schema = {
        "found_target": True,
        "reached": False,
        "reason": "目标在前方偏左，距离中等，需要先左转再前进。",
        "actions": ["turn_left_30", "forward_015m"],
    }
    return (
        "你是机器人短程导航规划器。"
        "根据当前机器人第一视角画面，判断目标物体是否可见，以及是否已经到达目标附近。"
        "目标物体是："
        f"{target}。"
        "只允许输出严格 JSON，不要输出 Markdown，不要解释，不要额外文本。"
        "JSON 字段必须是 found_target、reached、reason、actions。"
        "actions 必须是字符串数组，元素只能从以下四个动作中选择："
        "turn_left_30, turn_right_30, forward_015m, stop。"
        f"本轮最多输出 {max_actions} 个动作。"
        "如果目标不可见，found_target=false，并输出 stop。"
        "如果根据画面保守判断，目标已经明显很近，粗略估计约在 2 米内，"
        "或者目标已占画面较大区域、继续前进可能不安全，则 reached=true，并输出 stop。"
        "如果目标偏左，优先使用 turn_left_30；偏右则 turn_right_30；"
        "如果目标基本在前方且还能安全靠近，则使用 forward_015m。"
        "尽量保守，宁可早停，不要激进。"
        "返回示例："
        f"{json.dumps(schema, ensure_ascii=False)}"
    )


def call_kimi_with_image(
    *,
    image_bytes: bytes,
    prompt: str,
    config_path: str,
    max_tokens: int,
) -> Dict[str, Any]:
    config = load_openclaw_config(config_path)
    base_url, api_key, model = resolve_moonshot_settings(config)
    image_uri = "data:image/jpeg;base64," + base64.b64encode(image_bytes).decode("ascii")
    payload = {
        "model": model,
        "messages": [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": prompt},
                    {"type": "image_url", "image_url": {"url": image_uri}},
                ],
            }
        ],
        "max_tokens": max_tokens,
    }
    resp = requests.post(
        f"{base_url}/chat/completions",
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        json=payload,
        timeout=60,
    )
    resp.raise_for_status()
    return resp.json()


def call_kimi_text_only(
    *,
    prompt: str,
    config_path: str,
    max_tokens: int,
) -> Dict[str, Any]:
    config = load_openclaw_config(config_path)
    base_url, api_key, model = resolve_moonshot_settings(config)
    payload = {
        "model": model,
        "messages": [{"role": "user", "content": prompt}],
        "max_tokens": max_tokens,
    }
    resp = requests.post(
        f"{base_url}/chat/completions",
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        json=payload,
        timeout=60,
    )
    resp.raise_for_status()
    return resp.json()


def extract_text_payload(choice: Dict[str, Any]) -> str:
    message = choice.get("message", {})
    content = str(message.get("content") or "").strip()
    if content:
        return content
    reasoning = str(message.get("reasoning_content") or "").strip()
    if reasoning:
        return reasoning
    raise RuntimeError("vision model returned empty message")


def parse_json_object(raw_text: str) -> Dict[str, Any]:
    decoder = json.JSONDecoder()
    for idx, ch in enumerate(raw_text):
        if ch != "{":
            continue
        try:
            obj, _ = decoder.raw_decode(raw_text[idx:])
        except json.JSONDecodeError:
            continue
        if isinstance(obj, dict):
            return obj
    raise RuntimeError(f"model did not return JSON: {raw_text[:300]}")


def repair_plan_to_json(raw_text: str, config_path: str, max_tokens: int) -> Dict[str, Any]:
    repair_prompt = (
        "把下面这段导航分析改写成一个严格 JSON 对象。"
        "不要解释，不要 Markdown，只输出 JSON。"
        "字段必须是 found_target、reached、reason、actions。"
        "actions 只能是数组，元素只能从 turn_left_30、turn_right_30、forward_015m、stop 中选择。"
        f"\n原文如下：\n{raw_text}"
    )
    repaired = call_kimi_text_only(
        prompt=repair_prompt,
        config_path=config_path,
        max_tokens=max_tokens,
    )
    choice = repaired["choices"][0]
    return parse_json_object(extract_text_payload(choice))


def heuristic_plan_from_text(raw_text: str) -> Dict[str, Any]:
    lower = raw_text.lower()

    found_match = re.search(r"found_target\s*[:=]\s*(true|false)", lower)
    reached_match = re.search(r"reached\s*[:=]\s*(true|false)", lower)

    if found_match:
        found_target = found_match.group(1) == "true"
    else:
        found_target = ("可见" in raw_text) or ("visible" in lower)

    if reached_match:
        reached = reached_match.group(1) == "true"
    else:
        reached = ("已到达" in raw_text) or ("很近" in raw_text) or ("stop" in lower and "2米" in raw_text)

    reason_match = re.search(r"reason\s*[:：]\s*(.+)", raw_text, re.IGNORECASE)
    reason = reason_match.group(1).strip() if reason_match else raw_text.strip().splitlines()[0].strip()

    indexed_actions: List[tuple[int, str]] = []
    for action in ALLOWED_ACTIONS:
        idx = raw_text.find(action)
        if idx >= 0:
            indexed_actions.append((idx, action))
    indexed_actions.sort()
    actions = [action for _, action in indexed_actions]

    if not actions:
        if "左转" in raw_text:
            actions.append("turn_left_30")
        if "右转" in raw_text:
            actions.append("turn_right_30")
        if "前进" in raw_text or "靠近" in raw_text:
            actions.append("forward_015m")
        if "停止" in raw_text or "stop" in lower:
            actions.append("stop")

    if not actions:
        actions = ["stop"]

    return {
        "found_target": found_target,
        "reached": reached,
        "reason": reason,
        "actions": actions,
    }


def recover_plan(raw_text: str, config_path: str, max_tokens: int) -> Dict[str, Any]:
    try:
        return parse_json_object(raw_text)
    except Exception:
        pass

    try:
        repaired = repair_plan_to_json(raw_text, config_path, max_tokens)
        return repaired
    except Exception:
        pass

    return heuristic_plan_from_text(raw_text)


def validate_plan(plan: Dict[str, Any], max_actions: int) -> Dict[str, Any]:
    found_target = bool(plan.get("found_target"))
    reached = bool(plan.get("reached"))
    reason = str(plan.get("reason") or "").strip()
    actions = plan.get("actions")
    if not isinstance(actions, list):
        raise RuntimeError("actions must be a list")
    normalized: List[str] = []
    for action in actions[:max_actions]:
        action_name = str(action).strip()
        if action_name not in ALLOWED_ACTIONS:
            raise RuntimeError(f"unsupported action from model: {action_name}")
        normalized.append(action_name)
    if not normalized:
        normalized = ["stop"]
    return {
        "found_target": found_target,
        "reached": reached,
        "reason": reason,
        "actions": normalized[:max_actions],
    }


def http_json(method: str, url: str, payload: Dict[str, Any] | None = None) -> Dict[str, Any]:
    resp = requests.request(method, url, json=payload, timeout=30)
    resp.raise_for_status()
    return resp.json()


def request_and_execute(api_base: str, action_type: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    created = http_json(
        "POST",
        f"{api_base}/confirmations/request",
        {"action_type": action_type, "payload": payload},
    )
    confirmation_id = created["confirmation_id"]
    executed = http_json(
        "POST",
        f"{api_base}/confirmations/execute",
        {"confirmation_id": confirmation_id},
    )
    return executed


def execute_action(api_base: str, action: str) -> Dict[str, Any]:
    if action == "turn_left_30":
        planned = http_json("POST", f"{api_base}/motion/turn", {"angle_deg": DEFAULT_TURN_ANGLE_DEG})
        return request_and_execute(api_base, planned["action_type"], planned["payload"])
    if action == "turn_right_30":
        planned = http_json("POST", f"{api_base}/motion/turn", {"angle_deg": -DEFAULT_TURN_ANGLE_DEG})
        return request_and_execute(api_base, planned["action_type"], planned["payload"])
    if action == "forward_015m":
        planned = http_json(
            "POST",
            f"{api_base}/motion/velocity",
            {
                "vx": DEFAULT_FORWARD_SPEED_MPS,
                "vy": 0.0,
                "vyaw": 0.0,
                "duration": DEFAULT_FORWARD_DURATION_S,
            },
        )
        return request_and_execute(api_base, planned["action_type"], planned["payload"])
    if action == "stop":
        planned = http_json("POST", f"{api_base}/motion/stop", {"reason": "navigation_stop"})
        return request_and_execute(api_base, planned["action_type"], planned["payload"])
    raise RuntimeError(f"unknown action: {action}")


def build_round_summary(
    *,
    round_idx: int,
    image_sig: str,
    plan: Dict[str, Any],
    executed: List[Dict[str, Any]],
) -> Dict[str, Any]:
    return {
        "round": round_idx,
        "image_sig": image_sig,
        "found_target": plan["found_target"],
        "reached": plan["reached"],
        "reason": plan["reason"],
        "actions": plan["actions"],
        "executed": executed,
    }


def resolve_navigation_context(args: argparse.Namespace) -> tuple[str, Dict[str, Any], int]:
    if args.continue_nav:
        state = load_navigation_state(args.state_file)
        if not state.get("awaiting_continue"):
            raise RuntimeError("当前没有等待继续的导航任务")
        target = str(state.get("target") or "").strip()
        if not target:
            raise RuntimeError("导航状态缺少目标")
        round_idx = int(state.get("round", 0)) + 1
        return target, state, round_idx

    if not args.target:
        raise RuntimeError("请提供目标名，或者使用 --continue-nav")

    clear_navigation_state(args.state_file)
    return args.target, {}, 1


def run_navigation(args: argparse.Namespace) -> Dict[str, Any]:
    if args.cancel_nav:
        clear_navigation_state(args.state_file)
        return {
            "ok": True,
            "status": "cancelled",
            "message": "已清除当前导航任务。",
            "rounds": [],
        }

    http_json("GET", f"{args.api_base}/health")
    http_json("GET", f"{args.api_base}/camera/health")

    target, state, round_idx = resolve_navigation_context(args)
    image_bytes = fetch_image(args.image_url)
    img_sig = image_signature(image_bytes)
    prompt = build_navigation_prompt(target, args.max_actions)
    kimi_result = call_kimi_with_image(
        image_bytes=image_bytes,
        prompt=prompt,
        config_path=args.config,
        max_tokens=args.max_tokens,
    )
    choice = kimi_result["choices"][0]
    raw_text = extract_text_payload(choice)
    raw_plan = recover_plan(raw_text, args.config, args.max_tokens)
    plan = validate_plan(raw_plan, args.max_actions)

    previous_actions = state.get("previous_actions")
    lost_rounds = int(state.get("lost_rounds", 0))
    repeated_plan_rounds = int(state.get("repeated_plan_rounds", 0))

    if not plan["found_target"]:
        lost_rounds += 1
    else:
        lost_rounds = 0

    if previous_actions == plan["actions"]:
        repeated_plan_rounds += 1
    else:
        repeated_plan_rounds = 0

    executed: List[Dict[str, Any]] = []
    round_summary = build_round_summary(
        round_idx=round_idx,
        image_sig=img_sig,
        plan=plan,
        executed=executed,
    )

    if plan["reached"]:
        clear_navigation_state(args.state_file)
        return {
            "ok": True,
            "status": "reached",
            "target": target,
            "rounds": [round_summary],
            "message": f"已判断接近目标 {target}，本轮停止。无需继续。",
        }

    if lost_rounds >= args.lost_threshold:
        clear_navigation_state(args.state_file)
        return {
            "ok": False,
            "status": "target_lost",
            "target": target,
            "rounds": [round_summary],
            "message": f"连续 {lost_rounds} 轮未看到目标 {target}，已停止当前导航任务。",
        }

    if repeated_plan_rounds >= args.repeat_plan_threshold:
        if not args.dry_run:
            execute_action(args.api_base, "stop")
        clear_navigation_state(args.state_file)
        return {
            "ok": False,
            "status": "no_progress",
            "target": target,
            "rounds": [round_summary],
            "message": "连续多轮规划相同，疑似无进展，已停止当前导航任务。",
        }

    for action in plan["actions"]:
        if action == "stop":
            clear_navigation_state(args.state_file)
            return {
                "ok": plan["found_target"] and plan["reached"],
                "status": "stopped",
                "target": target,
                "rounds": [round_summary],
                "message": plan["reason"] or "规划要求停止。",
            }
        if args.dry_run:
            executed.append({"action": action, "dry_run": True})
            continue
        result = execute_action(args.api_base, action)
        executed.append({"action": action, "result": result})

    if not args.dry_run:
        save_navigation_state(
            args.state_file,
            {
                "target": target,
                "round": round_idx,
                "awaiting_continue": True,
                "previous_actions": plan["actions"],
                "lost_rounds": lost_rounds,
                "repeated_plan_rounds": repeated_plan_rounds,
                "last_reason": plan["reason"],
                "last_round": round_summary,
            },
        )

    return {
        "ok": True,
        "status": "awaiting_continue",
        "target": target,
        "rounds": [round_summary],
        "message": f"第 {round_idx} 轮已执行完成。若要继续靠近 {target}，请回复“继续”。",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Navigate G1 toward a visible target using Kimi.")
    parser.add_argument("target", nargs="?", help="Visible target object to approach, for example 椅子")
    parser.add_argument("--continue-nav", action="store_true", help="Continue the last pending navigation task")
    parser.add_argument("--cancel-nav", action="store_true", help="Cancel the pending navigation task")
    parser.add_argument("--api-base", default=DEFAULT_API_BASE, help="G1 adapter base URL")
    parser.add_argument("--image-url", default=DEFAULT_IMAGE_URL, help="Camera JPEG URL")
    parser.add_argument("--config", default=DEFAULT_CONFIG_PATH, help="OpenClaw config path")
    parser.add_argument("--state-file", default=DEFAULT_STATE_PATH, help="Navigation state file path")
    parser.add_argument("--max-actions", type=int, default=DEFAULT_MAX_ACTIONS, help="Max actions per round")
    parser.add_argument("--max-tokens", type=int, default=500, help="Max completion tokens")
    parser.add_argument("--lost-threshold", type=int, default=DEFAULT_LOST_THRESHOLD, help="Stop after this many lost-target rounds")
    parser.add_argument(
        "--repeat-plan-threshold",
        type=int,
        default=DEFAULT_REPEAT_PLAN_THRESHOLD,
        help="Stop after this many repeated identical plans",
    )
    parser.add_argument("--dry-run", action="store_true", help="Plan only, do not execute robot motions")
    parser.add_argument("--json", action="store_true", help="Print machine-readable JSON")
    args = parser.parse_args()

    try:
        result = run_navigation(args)
        if args.json:
            print(json.dumps(result, ensure_ascii=False))
        else:
            print(result["message"])
            for round_info in result["rounds"]:
                print(
                    f"第{round_info['round']}轮: found={round_info['found_target']} "
                    f"reached={round_info['reached']} actions={round_info['actions']} "
                    f"reason={round_info['reason'] or 'n/a'}"
                )
        return 0 if result.get("ok", False) else 1
    except Exception as exc:
        if args.json:
            print(json.dumps({"ok": False, "status": "error", "error": str(exc)}, ensure_ascii=False))
        else:
            print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
