# Deprecated Scripts

这些脚本保留作参考，**不要直接使用**。它们或依赖已下线的端口，或违反 `MISSION.md` 的"禁止直接 HTTP 调用控制/感知端点"规则。

- `g1_navigate_to_object.py` — 使用 `http://localhost:8001/camera/rgb.jpg` 直接取图，当前 8001 无服务；且绕过 `/code/execute`。正确做法参见 `skills/g1-people-in-view/` 和 `skills/abotclaw-sdk-discovery/`。
