# ROBOT.md — Fleet Reference (硬规则唯一真相源)

> 本文件是**硬规则的唯一真相源**。MISSION.md / TOOLS.md / AGENTS.md 提到的机器人规则，以本文为准。
> Agent 每次会话必读。

---

## 1. Fleet Endpoints


| Robot  | Base URL                     | SDK 文档                                                     | 状态    |
| ------ | ---------------------------- | ---------------------------------------------------------- | ----- |
| Piper  | `<PIPER_BASE_URL>`           | `/code/sdk/markdown`                                       | ❌ 未配置 |
| **G1** | `http://192.168.31.171:8888` | `/code/sdk/markdown`（`/docs/guide/html` 是 ROS 驱动层文档，非 SDK） | ✅ 已连接 |
| Go2    | `<GO2_BASE_URL>`             | `/code/sdk/markdown`                                       | ❌ 未配置 |


**本工作区当前只有 G1 可用**，以下规则均以 G1 为对象。Piper/Go2 规则留空待填。

---

## 2. 调用路径选择（三级优先）⭐ 最核心规则

**给 agent 最容易踩的坑就是"什么都往 `/code/execute` 里塞"。按以下三级优先挑路径。**

### 路由真相源（遇到不认识的端点，按此顺序找，禁止凭感觉猜）

1. **本文件 §2 Level 1 表格** — 人工精选的短 HTTP 端点（lease / memory / health / `GET` 位姿 / code 元数据等；**长时导航见 Level 2**）
2. `**GET http://192.168.31.171:8888/openapi.json`** — FastAPI 自动生成的**全量路由清单**（机器可读 JSON，含所有 `/lease/*`, `/nav/*`, `/face/*`, `/memory/*`, `/code/*`, `/cameras/*`, `/tts/*`, `/state/*` 路由）
3. `**GET http://192.168.31.171:8888/docs`** — Swagger UI（人可读）
4. 上述 3 步都没命中 → **停，按 §6 错误协议报告用户**，**不要猜路径**

**典型反例**（Kimi 实际犯过的错）：

- ❌ 把 lease 拼成 `POST /code/lease`（实际是 `POST /lease/acquire`，在独立的 `/lease/*` 命名空间）
- ❌ 把 face 识别拼成 `POST /face/recognize_current`（没这端点；复合动作走 `/code/execute` 用预注入 `face` 对象）
- ❌ 从 `GET /code/sdk/*` 里找 HTTP 路由（那是 **Python 对象清单**，不含 HTTP 路由）

> `**/code/sdk/*` 和 `/openapi.json` 是两个维度**：
>
> - `/code/sdk/*` 回答"**我在 Python 代码里能用什么变量**"
> - `/openapi.json` 回答"**我在外部 curl 时能调什么端点**"

### Level 1 — 单条 HTTP、短平快、**不牵动机器人长时间受控运动**（不进 /code/execute）

下列操作是「**一条请求就结束**」的元数据 / 租约 / 急停 / 查表，**直接 `curl`** 即可，**不写** `code_executions` 里的 Python：


| 操作                           | 端点                                                          | 方法                                                                                                                                                        |
| ---------------------------- | ----------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 查服务活没活                       | `GET http://192.168.31.171:8888/health`                     | —                                                                                                                                                         |
| 查机器人当前状态                     | `GET http://192.168.31.171:8888/state`                      | —                                                                                                                                                         |
| 查当前位姿（x/y/z/yaw/qx/qy/qz/qw） | `GET http://192.168.31.171:8888/nav/current_pose`           | ⚠️ 依赖 TF `map→body`，TF 未就绪时返回错误；优先在 `/code/execute` 内用 `Nav2Anywhere.get_current_pose()` |
| 查当前位姿（TF 方式，推荐）          | `/code/execute` 内 `Nav2Anywhere().get_current_pose()`       | 通过 TF `map→body` 查询，返回 `PoseStamped`；TF 未连通时返回 `None`                                                                                      |
| 导航到目标点（快速下发，不等到达）         | `POST http://192.168.31.171:8888/nav/simple_goal`             | `{"x":<float>,"y":<float>,"yaw":<float>,"frame_id":"map"}`（yaw 弧度，直接发 topic，不阻塞，无 lease 要求）                                                               |
| 查 SDK 目录                     | `GET http://192.168.31.171:8888/code/sdk/modules`           | —                                                                                                                                                         |
| 查 SDK 详细文档                   | `GET http://192.168.31.171:8888/code/sdk/markdown`          | —                                                                                                                                                         |
| 查 memory 里的地点                | `POST http://192.168.31.223:8022/query/place`                 | `{"name":"<地点名>","n_results":1}`                                                                                                                          |
| 写入 memory 地点                 | `POST http://192.168.31.223:8022/memory/place/upsert`         | `{"place_name":"<地点名>","robot_id":"g1_001","robot_type":"humanoid","place_pose":{"x":..,"y":..,"z":..,"qx":..,"qy":..,"qz":..,"qw":..,"frame_id":"map"}}` |
| 租约申请                         | `POST http://192.168.31.171:8888/lease/acquire`             | `{"holder":"<your_name>"}`                                                                                                                                |
| 释放租约                         | `POST http://192.168.31.171:8888/lease/release`             | `{"lease_id":"<id>"}`                                                                                                                                     |
| 代码急停                         | `POST http://192.168.31.171:8888/code/stop`                 | —                                                                                                                                                         |
| 查执行结果                        | `GET http://192.168.31.171:8888/code/result/<execution_id>` | 返回 `{"status":"completed"/"running"/"timeout", "exit_code":..., "stdout":"...", "stderr":"..."}`                                                          |


**已从 Level 1 移除**：`POST /nav/to_pose` —— 与「人脸识别、抓取」同属 **在 lease 下长时间占用机器人** 的行为，**默认与 face 同级，走 Level 2**（见下）。

> **调试例外**：`POST /nav/to_pose` 仍在 `openapi.json` 中，仅供人工 smoke / 排障；**OpenClaw 任务编排默认不要用「先 curl 导航再等很久再 execute 人脸」**，否则极易出现 **lease 在空窗期过期**（你日志里已发生）。

> **导航端点选择**：
> - `POST /nav/simple_goal`（**推荐**）：fire-and-forget，**无需 lease**，响应快（毫秒级），适合"下发目标后不管"或与别的 lease 操作并行。**返回不含到达结果**，只保证目标已发出。
> - `Nav2Anywhere`（Level 2）：Python SDK，**需要 lease**，基于 **ROS1 `move_base`** + **TF `map→body`** 实现，支持 `nav_to_pose` + `wait_until_reached`，适合需要在代码里判断到达状态后再做下一步的场景。

### Level 2 — 需要 lease 下的机器人行为、或 Python 逻辑（条件 / 循环 / 多段组合），用 /code/execute

典型场景：

- **导航到 map 位姿（含从 memory 查到坐标再走、再等到达）** → 与 `face` / `camera` 一样，用 **预注入 `Nav2Anywhere`**（`nav_to_pose` + `wait_until_reached`），**与人脸写在同一段 `code` 里优先**，同一 `X-Lease-Id` 串完再 release。
- **快速下发导航目标，不等到达** → `POST /nav/simple_goal`（**无需 lease**，毫秒级响应），适合"走过去做其他事"的编排，可与其他 lease 操作并行。
- **人脸识别 / 读相机 / YOLO / 抓取** → 预注入 `face` / `camera` / `yolo` / `grasp_`*，进 `/code/execute`。
- "先查起点，**如果**距离超过 2m 再走" → 有 `if`，进 `/code/execute`
- "抓起瓶子，**失败则**换策略" → 有重试，进 `/code/execute`
- "遍历每个 detection，按 confidence 排序取第一个" → 有 `for`，进 `/code/execute`

**提交方式是"不可拆的三步原子流程"**：

```
Step A: POST http://192.168.31.171:8888/lease/acquire
        Body:    {"holder":"<your_task_name>"}
        Returns: {"lease_id":"<uuid>", ...}          ← 必须拿到真实 uuid

Step B: POST http://192.168.31.171:8888/code/execute
        Headers: X-Lease-Id: <Step A 返回的 uuid>    ← ★★★ 放 Header，不是 Body
                 Content-Type: application/json
        Body:    {"code":"<python字符串>", "timeout":<秒>}

Step C（必做，含 OpenClaw 用 exec/curl 编排时）: **显式释放租约**，不要假设「执行器会自动退租」。
        POST http://192.168.31.171:8888/lease/release
        Headers: Content-Type: application/json
        Body:    {"lease_id":"<Step A 返回的同一 uuid>"}
        例（把 <uuid> 换成真实值）:
        curl -s -X POST http://192.168.31.171:8888/lease/release \
          -H "Content-Type: application/json" \
          -d '{"lease_id":"<uuid>"}'
        **时机**：Step B 返回后（成功 / 超时 / 子进程报错）**以及**向用户汇报「任务完成」**之前**；若 Step B 未发起则无需 release（未持有 lease）。
        **失败/重试**：若还要用同一 holder 再 acquire，也须先对旧 `lease_id` release（或等其过期），避免占租约导致后续 `acquire` 失败。
```

**禁止动作（违反会被服务端拒，不要尝试）**：

- ❌ **跳过 Step A 直接打 Step B** — 返回 `{"detail":"Missing X-Lease-Id header"}`
- ❌ **伪造 / 猜测 `X-Lease-Id`**（如 `test-lease-123`、`abc`、旧会话的 uuid）— 返回 `{"detail":"Invalid or expired lease"}`
- ❌ **把 `lease_id` 塞进 Body 而不是 Header** — 服务端只认 Header，Body 里的字段**会被忽略**
- ❌ **把 lease 端点拼成 `/code/lease`、`/execute/lease`** — 正确前缀是 `/lease/*`
- ❌ **持有 lease 跑完 `/code/execute` 却不调 `/lease/release`** — OpenClaw 常见遗漏；占租约会导致他人 `acquire` 失败，必须在汇报完成前 release（见上 Step C）

**/code/execute 子进程内的硬约束**：

- ❌ **禁止 `import`**：`requests` / `httpx` / `urllib` / `socket` / `subprocess` / `shutil` / `multiprocessing` / `pickle` 等（被安全层拦，见 `code_executor.py` BLOCKED_IMPORTS）
- ❌ **禁止直接 `from robot_sdk.ik import ...`**（用预注入 `grasp_target` 代替）
- ✅ **可以 `from robot_sdk.navigation_sdk import Nav2Anywhere`**（**需要 lease / 等待到达的场景用此路径**，与 `face` / `grasp_*` 同一段 `/code/execute`，租约一致）；**不要**为省事先 `curl /nav/to_pose` 再单独 execute（lease 时间线易断）；**快速下发不等待的场景用 `POST /nav/simple_goal`**（无需 lease，毫秒响应）
- ✅ **Nav2Anywhere 内部自动 `rospy.init_node()`**，无需在 `/code/execute` 里手动 `import rospy; rospy.init_node(...)`（重复 init 会抛异常）
- ✅ **可以 `from geometry_msgs.msg import PoseStamped`**（ROS1/ROS2 通用）
- ❌ **不要 `import rclpy`** — G1 部署的是 **ROS1**（`rospy`），没有 `rclpy` 包
- ✅ 用**预注入对象**（见下表）即可满足 90% 感知 / 操控需求

### 图片保存与 `image` 工具

- `/code/execute` 里拍照后若要用 OpenClaw 的 `**image` 工具**（让模型看图 / 描述画面），**必须把图片保存到 workspace 目录**：`~/.openclaw/workspace/`
- ❌ 保存到 `/tmp/` 或其他目录 → `image` 工具会拒绝访问
- 示例：
  ```python
  import cv2
  rgb, depth = camera.get_frame()
  cv2.imwrite("~/.openclaw/workspace/scene.jpg", cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR))
  ```
  然后在 `/code/execute` 外用 `image` 工具分析 `~/.openclaw/workspace/scene.jpg`

> **注意**：请将 `~/.openclaw/workspace/` 替换为当前 `.openclaw` 文件夹所在的实际路径。

### Nav2Anywhere 内部机制与 TF 依赖（CRITICAL）

**Nav2Anywhere 是基于 ROS1 `move_base` + TF 的导航 SDK**，关键实现细节：

| 机制 | 说明 | 对 Agent 的影响 |
|------|------|----------------|
| **位姿查询** | `get_current_pose()` 通过 **TF `map → body`** 查询，不是订阅 `/amcl_pose` 或 `/slam_odom` | TF 树未就绪时返回 `None`，`wait_until_reached` 会卡住 |
| **目标发布** | `nav_to_pose()` 连续发布 **3 次**到 `/move_base_simple/goal`（间隔 0.5s） | 确保机器人收到目标，但**不保证 move_base 能规划出路径** |
| **到达判定** | `wait_until_reached()` 同时检查：**位置误差 ≤ 0.2m** AND **朝向误差 ≤ 0.2rad** | 两个条件必须同时满足，否则视为未到达 |
| **TF 帧名** | 默认 `parent_frame="map"`, `child_frame="body"` | 如果机器人实际用 `base_link`/`base_footprint`，TF 查询会失败 |
| **ROS 初始化** | 类内部自动 `rospy.init_node("nav2anywhere", anonymous=True)` | **不要在 `/code/execute` 里再手动 `rospy.init_node()`** |

**导航卡住时的排查顺序**：
1. TF 树是否连通？`map → body` 是否存在？
2. `move_base` 是否运行？是否有可行路径？
3. 机器人是否被障碍物挡住？
4. `child_frame` 名称是否正确（可能是 `base_link` 而非 `body`）？

**调试命令**（在机器人 PC 上执行）：
```bash
# 查看 TF 树
rosrun tf view_frames

# 实时查看 TF
rosrun tf tf_echo map body

# 查看 move_base 状态
rostopic echo /move_base/status
```

---

### 「描述当前场景」的首选方式

当用户要求「描述画面 / 看看面前有什么 / 描述场景」时，**优先在 `/code/execute` 里直接调 `vision.describe_current_frame()`**，一步完成拍照 + VL 描述，**不要**先拍照保存 jpg 再跳出 execute 用 `image` 工具（多一轮往返、容易 lease 过期）。

```python
# ✅ 推荐（一步到位）
result = vision.describe_current_frame()
print(result)

# ✅ 自定义 prompt
result = vision.describe_current_frame(prompt="画面里有几个人？")
print(result)

# ❌ 不推荐（拍照 → 保存 → 退出 execute → image 工具 → 再看图）
```

### Level 3 — 只读发现（与 Level 1 中 GET 重叠，强调「无副作用」）

**含义**：只做 **GET**、不改变机器人状态、**不需要 lease** 的发现类请求（health、state、`/code/sdk/*`、`openapi.json`、ROS 文档等）。

与 Level 1 表里 **GET 行**同一类；单独写 Level 3 是为了强调：**凡是会动机器人 / 占 lease 的，都不属于 Level 3。**

---

### 三级一眼表（给 agent 自检）


| Level | 一句话                         | 典型手段                                                                                 | 会写 `code_executions/*.py`？ |
| ----- | --------------------------- | ------------------------------------------------------------------------------------ | -------------------------- |
| **1** | 短 HTTP；不动长时间机体              | `curl` health / lease / query_place / `GET current_pose`                             | 否                          |
| **2** | lease + 机体 / 感知 / 导航 / 脚本逻辑 | `lease/acquire` → `/code/execute`（`Nav2Anywhere`、`face`、`grasp_*`…）→ `lease/release` | **是**（每次 execute 一条）       |
| **3** | 只读 GET 发现                   | `curl -s GET ...`、浏览器看 `/docs`                                                       | 否                          |


---

## 3. `/code/execute` 预注入对象清单

**以下变量在子进程里已经是活的对象，直接用，不用 import**：


| 名字                           | 类型                                      | 用途                                                                                                                            |
| ---------------------------- | --------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------- |
| `env`                        | `G1RobotEnv`                            | 组合门面，含 `env.read_cameras()` 等                                                                                                 |
| `camera`                     | D455 RGB-D（水平朝前）                        | `rgb, depth = camera.get_frame()` → rgb: `np.ndarray (H,W,3) uint8`，depth: `np.ndarray (H,W) float32`（米）；**返回 tuple 不是 dict** |
| `camera_d435i`               | D435i RGB-D（倾斜朝下）                       | `rgb, depth = camera_d435i.get_frame()` — 同上格式，仅抓取用                                                                           |
| `yolo`                       | YoloSDK（lazy）                           | `yolo.detect_on_rgb(rgb)`、`yolo.detect_env()`、`yolo.segment_3d(label)`                                                        |
| `face`                       | FaceSDK                                 | `face.recognize_current_frame()`（返回 dict，含 `results` 列表）                                                                      |
| `memory`                     | MemorySDK                               | `memory.query_place(name)`、`memory.upsert_place(...)`                                                                         |
| `tts`                        | TTS                                     | `tts.initialize()` → `tts.speak(text)`                                                                                        |
| `vision`                     | Kimi VL 多模态场景描述（懒加载）                    | `result = vision.describe_current_frame()` 或 `vision.describe(rgb, prompt="...")` → 返回中文描述字符串                                 |
| `grasp_target(r_pos, l_pos)` | function                                | 坐标已知的精细抓取                                                                                                                     |
| `grasp_something(name)`      | function                                | 一句话检测+抓取（失败返回 False）                                                                                                          |
| `release_object()`           | function                                | 放下 / 松手（回 home + 打开灵巧手）                                                                                                       |
| `release_something()`        | function                                | 放下 / 松手（完整封装，home → lift → 放置位 → 松手 → 回撤）                                                                                     |
| `Nav2Anywhere`               | **class**（非实例；**ROS1，SDK 内部自动 `rospy.init_node()`**） | `nav = Nav2Anywhere(); nav.nav_to_pose(pose); nav.wait_until_reached(timeout_sec=...)`；也支持 `nav.publish_simple_goal(x, y, yaw)` |
| `Pose`                       | class（`memory_sdk.Pose`）                | 构造 memory 地点用                                                                                                                 |


**不要假设其他名字存在**；不在上表里的都当不存在，先走 `GET /code/sdk/modules` 确认。

---

## 4. 相机绑定规则（CRITICAL）

**铁律：违反会看错视角 / 数错人 / 抓偏。**


| 相机        | 安装            | 视野             | **唯一用途**             | 对应对象                                                                               |
| --------- | ------------- | -------------- | -------------------- | ---------------------------------------------------------------------------------- |
| **D455**  | 头部，**水平朝前**   | 站立的人 / 场景 / 远景 | 人脸识别 + **其它一切朝前视觉**  | `camera` / `env.camera` / `face`                                                   |
| **D435i** | 手臂附近，**倾斜朝下** | 手下方 / 桌面       | **仅抓取**（且抓取**必须**用它） | `camera_d435i` / `yolo.detect_env()` / `yolo.segment_3d(...)/grasp_something(...)` |


### 硬选择规则


| 任务               | 用哪个调用                                                       | 相机    |
| ---------------- | ----------------------------------------------------------- | ----- |
| 画面里有几个人 / 都是谁    | `face.recognize_current_frame()`                            | D455  |
| 画面里有什么物体（非抓取）    | `rgb, _ = camera.get_frame(); yolo.detect_on_rgb(rgb)`      | D455  |
| 抓取前找桌面物体         | `yolo.detect_env()` 或 `yolo.segment_3d("bottle")`           | D435i |
| 执行抓取             | `grasp_target(...)` / `grasp_something(name)`               | D435i |
| 导航到 map 位姿（含等到达） | `**/code/execute` + `Nav2Anywhere`**（Level 2，与人脸/抓取同 lease） | —     |


**永远不要用 `yolo.detect_env()` 去数站立的人**——它内部绑 D435i，视野偏地面，看不到站着的人。

---

## 5. 导航朝向规则（CRITICAL）

**导航到空间记忆中的地点时，必须确保机器人到达后的 yaw 角度与记忆中记录的角度朝向一致，误差在 ±10° 以内可接受。**

### 为什么重要

- 人形机器人到达地点后通常需要执行**面向特定方向的交互任务**（如面对柜台、面对门、面对用户）
- 只到达位置但朝向错误，可能导致：
  - 人脸识别时看不到目标（相机朝错方向）
  - 抓取时手臂够不到目标（身体朝向错误）
  - TTS 交互时面向墙壁或空处

### 正确做法

1. **从 memory 获取完整位姿**（含四元数 qx, qy, qz, qw 或欧拉角 roll, pitch, yaw）
2. **构造 PoseStamped 时必须包含 orientation**，不能只用 position
3. **使用 `Nav2Anywhere.nav_to_pose(pose)` 时传入完整 6-DoF 位姿**
4. **到达后检查当前朝向**（可选，用 `env.get_robot_pose()` 或 `GET /nav/current_pose`）

### 示例代码

```python
from geometry_msgs.msg import PoseStamped

# SDK 内部自动 rospy.init_node()，不需要手动 import rospy
nav = Nav2Anywhere()

# ✅ 正确：使用 memory 返回的完整位姿（含朝向）
pose = PoseStamped()
pose.header.frame_id = "map"
pose.pose.position.x = target_pose["x"]
pose.pose.position.y = target_pose["y"]
pose.pose.position.z = target_pose["z"]
pose.pose.orientation.x = target_pose["qx"]
pose.pose.orientation.y = target_pose["qy"]
pose.pose.orientation.z = target_pose["qz"]
pose.pose.orientation.w = target_pose["qw"]

nav.nav_to_pose(pose)
reached = nav.wait_until_reached(timeout_sec=60)
```

### 禁止行为

- ❌ 只取 x, y，忽略 yaw/qx/qy/qz/qw，自己填 `qw=1.0`（朝向变成默认 0°）
- ❌ 用 `POST /nav/to_pose` 只传位置不传朝向（HTTP API 同样需要完整位姿）
- ❌ 用 `POST /nav/simple_goal` 传四元数（该端点只接受 yaw/pitch/roll，不支持 qx/qy/qz/qw）
- ❌ 到达后不验证朝向是否正确

### 特殊情况处理

- **memory 中只有 yaw（无四元数）**：用欧拉角转四元数公式转换
  ```python
  import math
  cy = math.cos(yaw * 0.5)
  sy = math.sin(yaw * 0.5)
  pose.pose.orientation.x = 0.0
  pose.pose.orientation.y = 0.0
  pose.pose.orientation.z = sy
  pose.pose.orientation.w = cy
  ```
- **`/nav/simple_goal` 使用 yaw 而非四元数**：该端点只接受弧度 yaw/pitch/roll，无需自己转四元数
- **Nav2 不支持精确朝向**：到达位置后原地旋转到目标角度（需额外代码实现）

---

## 6. 空间记忆使用规则

从空间记忆取位姿后，**必须使用完整 6-DoF 信息**：

- **position**: `x`, `y`, `z`
- **orientation**: `qx`, `qy`, `qz`, `qw`（四元数）

`memory.query_place()` 返回的 `target_pose` 是**扁平结构**：

```json
{
  "x": ..., "y": ..., "z": ...,
  "roll": ..., "pitch": ..., "yaw": ...,
  "qx": ..., "qy": ..., "qz": ..., "qw": ...,
  "frame_id": "map"
}
```

**禁止**：

- ❌ 只取 `x/y` 忽略朝向，自己填 `qw=1.0`
- ❌ 假设有 `target_pose["orientation"]` 这种嵌套层（**没有**，是扁平的）
- ❌ 用不完整的姿态发起导航（无论 `Nav2Anywhere` 还是调试用的 `POST /nav/to_pose`）
- ❌ 用 `POST /nav/simple_goal` 传 memory 中的四元数（端点只接受 yaw 弧度）

---

## 7. 错误处理协议（CRITICAL）

**遇到错误/异常时的正确行为**：

1. **立即 STOP**——不要自动重试 / 绕过 / 改代码
2. **SUMMARIZE**——总结问题（一两句话 + 具体错误消息）
3. **REPORT**——把问题报给用户
4. **WAIT**——等用户指示再继续

**禁止行为**：

- ❌ 自动重试失败的操作
- ❌ 擅自尝试替代方案
- ❌ 猜测原因并修改代码 / 配置
- ❌ 出错后仍然继续下一步

**典型正确回应**：

> "遇到以下问题：`<简短总结>`。具体错误：`<错误消息 / 日志>`。请问你希望如何处理？"

---

## 8. 时间限制（`/code/execute` 超时）

- **硬超时**由 `/code/execute` 请求体的 `"timeout": <秒>` 控制（默认 300s）
- Lease 的 idle timeout（默认 60s）是**空闲超时**——衡量"无新命令 / 无关节运动"，不是"任务必须在 60s 内完成"
- 用户说"必须 60s 内完成"→ **必须** 在 JSON body 里带 `"timeout": 60`，嘴上说不算

---

## 9. 服务端口（实测 2026-05-06）


| 服务                | URL                          | 状态                  |
| ----------------- | ---------------------------- | ------------------- |
| G1 agent_server   | `http://192.168.31.171:8888` | ✅ 已连接（机器人 PC2）      |
| G1 YOLO           | `http://192.168.31.223:8013`   | ✅（cuda:0, yolov5l6） |
| G1 Face           | `http://192.168.31.223:8016`   | ✅（buffalo_l）        |
| G1 Spatial Memory | `http://192.168.31.223:8022`   | ✅（本地 SQLite）        |
| G1 AnyGrasp       | `http://192.168.31.223:8015`   | ✅（抓取位姿计算）           |
| G1 D455 RGB (ZMQ) | `tcp://192.168.31.171:5555`  | ✅                   |
| G1 D435i (TCP)    | `192.168.31.171:8765`        | ✅                   |
| Piper             | —                            | ❌ 未配置               |
| Go2               | —                            | ❌ 未配置               |


- `enp7s0` 网卡 IP = `192.168.31.225`，只在**对机器人网段**通信时相关
- 对 OpenClaw 自身服务（memory / yolo / face），**一律用 `192.168.31.225`**
- **agent_server 在机器人 PC2 上**，OpenClaw 调用用 `192.168.31.171:8888`

---

## 10. 安全 / E-stop

- **硬件 E-stop**：G1 本体红色急停按钮
- **软件急停**：`POST http://192.168.31.171:8888/lease/release`（释放租约 → 当前执行被中止）
- **代码级停止**：`POST http://192.168.31.171:8888/code/stop`
- **异常后先退租约再报告**——避免占住机器人
- G1 质量大、力矩高；运动前确认 **1.5m 无人**；抓取前确认工作面清空
- **没有仿真兜底**——真机直接执行

---

## 11. Skill Template

每个 skill 必须声明：

1. **Target robot**（Piper / G1 / Go2）
2. **Sensor/actuator assumptions**——显式说明用 D455 还是 D435i
3. **调用路径**——走 Level 1 HTTP / Level 2 `/code/execute` / 混合（**含导航的复合任务以 Level 2 串 lease 为主**）
4. **Safety checks**——lease 获取 / E-stop 预案 / 活动范围确认
5. **Supervision required?**——是否需要人盯着

---

## 12. 机器人状态检查清单（Status Checklist）

> **每次用户要求"检查机器人状态"时，必须按以下 6 项逐一检查并汇报。**

| 序号 | 检查项 | 检查方法 |
|------|--------|----------|
| 1 | **Agent Server 是否在线** | `curl -s http://192.168.31.171:8888/health` |
| 2 | **机器人连接是否正常** | `curl -s http://192.168.31.171:8888/state` → 检查 `connected`, `sport_ready`, `arm_ready` |
| 3 | **D455 摄像头是否在线** | `/code/execute` 内调用 `camera.get_frame()`，检查返回的 rgb/depth 是否为 `np.ndarray` |
| 4 | **D435i 摄像头是否在线** | `/code/execute` 内调用 `camera_d435i.get_frame()`，同上 |
| 5 | **灵巧手是否连接成功** | `echo "s" \| nc -w 2 192.168.31.171 5678`，检查 `right_hand.status` / `left_hand.status` |
| 6 | **四个服务是否正常** | 分别 curl YOLO(8013)、Face(8016)、AnyGrasp(8015)、Spatial Memory(8022) 的健康端点 |

### 服务健康检查端点

| 服务 | URL | 预期响应 |
|------|-----|----------|
| YOLO | `http://192.168.31.225:8013/health` 或 `/` | HTTP 200 |
| Face | `http://192.168.31.225:8016/health` 或 `/` | HTTP 200 |
| AnyGrasp | `http://192.168.31.225:8015/health` 或 `/` | HTTP 200 |
| Spatial Memory | `http://192.168.31.225:8022/health` 或 `/` | HTTP 200 |

> 注：若服务未暴露 `/health`，可尝试 `curl -s -o /dev/null -w "%{http_code}" <url>` 检查是否能通。

---

## 13. 连接状态摘要（2026-04-20）

- ✅ **G1**：本地连接正常，具备视觉（D455+D435i）、YOLO、Face、TTS、空间记忆、ROS1 导航（`rospy` + `move_base`）
- ❌ Piper：未配置端点
- ❌ Go2：未配置端点

---

## 14. 抓取与释放 SDK

### 14.1 检测 + 抓取一体化 — `grasp_something`

**SDK 文件**：`robot_client/unitree_G1/agent_server/robot_sdk/grasp_something_sdk.py`

**对外接口**：

```python
from robot_sdk.grasp_something_sdk import grasp_something

grasp_something(
    object_name: str,                    # 目标类别名，例如 "bottle"
    *,
    robot_ip: Optional[str] = None,      # 灵巧手所在机器人 IP
    detection_index: int = 0,            # 多目标时按置信度排序后选取的索引
    right_target_offset: Optional[Sequence[float]] = None,  # 可选右手抓取偏移
    log_dir: Optional[str | Path] = None,  # 检测图保存目录，默认 agent_server/logs
) -> bool
```

**封装流程**：

1. YOLO 检测指定目标（通过 D435i）
2. 保存一张当前检测图到 agent_server/logs
3. 根据检测结果执行抓取（调用 `grasp_target`）
4. 结束后回到 home 位并释放控制权

**使用示例**：

```python
# 抓取瓶子
success = grasp_something("bottle")

# 抓取特定索引的瓶子（多目标时）
success = grasp_something("bottle", detection_index=1)

# 指定机器人 IP
success = grasp_something("bottle", robot_ip="192.168.31.171")
```

**依赖服务**：AnyGrasp 服务（`http://192.168.31.225:8015`）、D435i 相机（`192.168.31.171:8765`）

---

### 14.2 放下物体 — `release_something`

**SDK 文件**：`robot_client/unitree_G1/agent_server/robot_sdk/release_something_sdk.py`

**对外接口**：

```python
from robot_sdk.release_something_sdk import release_something

release_something(
    *,
    robot_ip: Optional[str] = None,  # 灵巧手所在机器人 IP
) -> bool
```

**封装流程**：

1. 执行放置/松手序列（home → lift → 固定放置位 → 灵巧手松开 → 回撤）
2. 结束后回到 home 位并释放控制权

**使用示例**：

```python
# 放下物体
success = release_something()

# 指定机器人 IP
success = release_something(robot_ip="192.168.31.171")
```

> **注意**：`release_something` 是 `release_object` 的完整封装版本（见下对比表）。两者均为预注入对象，无需 import。

---

### 14.3 对照表：预注入对象 vs SDK 函数


| 功能       | 预注入对象               | SDK 文件                     | 说明                                        |
| -------- | ------------------- | -------------------------- | ----------------------------------------- |
| 检测+抓取    | `grasp_something`   | `grasp_something_sdk.py`   | 一体化抓取，直接用，无需 import                       |
| 坐标抓取     | `grasp_target`      | `g1_grasp_sdk.py`          | 指定坐标抓取，直接用，无需 import                      |
| 释放（基础）   | `release_object`    | `g1_grasp_sdk.py`          | 回 home + 打开灵巧手，直接用，无需 import              |
| 释放（完整封装） | `release_something` | `release_something_sdk.py` | home → lift → 放置位 → 松手 → 回撤，直接用，无需 import |


---

### 14.4 完整任务示例

```python
# 先 acquire lease（Step A）...
# Headers: X-Lease-Id: <lease_id>

# 抓取瓶子（预注入对象，无需 import）
success = grasp_something("bottle")
if success:
    print("抓取成功！")
    # 导航到目标位置...
    # 放下瓶子（预注入对象，无需 import）
    release_something()
else:
    print("抓取失败")

# lease release（Step C）...
```

---

### 14.5 注意事项

1. **grasp_something 依赖 AnyGrasp 服务**（端口 8015），服务异常时会返回 `Connection refused`
2. **release_object / release_something 依赖 RobotBridge**（DDS 通信）
3. 两者都需要正确的机器人 IP 和网络配置
4. 抓取前确保 D435i 相机可用
5. 释放前确保机械臂处于安全位置
6. 如果 AnyGrasp 服务不可用，可回退到 `grasp_target` 直接指定坐标抓取

---

## 15. 灵巧手控制 SDK（hand_sdk.py）

G1 灵巧手通过 **TCP 连接**到机器人上的 hand server（端口 `5678`）进行控制。

**SDK 文件**：`robot_client/unitree_G1/agent_server/robot_sdk/hand_sdk.py`

---

### 15.1 命令列表


| 命令             | 动作                     | 说明    |
| -------------- | ---------------------- | ----- |
| `1`            | Left hand open         | 左手张开  |
| `2`            | Left hand fist         | 左手握拳  |
| `3`            | Left hand half grip    | 左手半握  |
| `4`            | Left hand pinch        | 左手捏合  |
| `5`            | Left hand bottle grip  | 左手握瓶  |
| `6`            | Left hand peace sign   | 左手剪刀手 |
| `7`            | Right hand open        | 右手张开  |
| `8`            | Right hand fist        | 右手握拳  |
| `9`            | Right hand half grip   | 右手半握  |
| `10`           | Right hand pinch       | 右手捏合  |
| `11`           | Right hand bottle grip | 右手握瓶  |
| `12`           | Right hand peace sign  | 右手剪刀手 |
| `13`           | Both hands open        | 双手张开  |
| `14`           | Both hands fist        | 双手握拳  |
| `15`           | Both hands half grip   | 双手半握  |
| `16`           | Both hands pinch       | 双手捏合  |
| `17`           | Both hands bottle grip | 双手握瓶  |
| `18`           | Both hands soft grip   | 双手轻握  |
| `19`           | Both hands alternating | 双手交替  |
| `s` / `status` | Query status           | 查询状态  |


---

### 15.2 使用方法

#### 方式一：Python SDK（推荐）

```python
from robot_sdk.hand_sdk import HandClient, send_hand_command

# 方式 1：使用上下文管理器
with HandClient("192.168.31.171", port=5678) as client:
    response = client.send("7")   # 右手张开
    print(response)
    response = client.send("11")  # 右手握瓶
    print(response)

# 方式 2：一键发送命令
response = send_hand_command("7", robot_ip="192.168.31.171")
print(response)
```

#### 方式二：命令行（nc）

```bash
# 右手张开
echo "7" | nc 192.168.31.171 5678

# 右手握瓶
echo "11" | nc 192.168.31.171 5678

# 查询状态
echo "s" | nc 192.168.31.171 5678
```

> **注意**：将 `192.168.31.171` 替换为实际机器人 IP。

---

### 15.3 HandClient API

```python
class HandClient:
    def __init__(self, host: str, port: int = 5678)
    def connect(self, timeout: float = 5.0) -> None
    def send(self, cmd: str) -> str          # 发送命令，返回服务器响应
    def close(self) -> None
    def __enter__(self)                      # 上下文管理器入口
    def __exit__(self, *args)                # 上下文管理器出口

def send_hand_command(cmd: str, robot_ip: Optional[str] = None, port: int = 5678) -> str
```

---

## 16. 语音 / TTS SDK（voice_sdk.py）

G1 机器人的语音控制通过 **DDS RPC** 与板载 voice 服务通信，底层依赖：

- `unitree_sdk2py.g1.audio.g1_audio_client.AudioClient`（DDS RPC）
- `unitree_sdk2py.g1.loco.g1_loco_client.LocoClient`（激活 G1 服务）

网卡默认 `enp4s0`，可通过环境变量 `G1_NETWORK_INTERFACE` / `UNITREE_IFACE` / `G1_ARM_NETWORK_IFACE` 覆盖。

**默认音量**: 100（最大值，2026-04-30 设置）

---

### 16.1 预注入对象 `tts`（/code/execute 内直接用，无需 import）

`tts` 已在 `/code/execute` 子进程中预注入为 `TTS` 实例：

```python
# ✅ 直接用，无需 import
tts.initialize()
tts.speak("你好，我是 G1 机器人")
tts.set_volume(100)  # 音量范围 0-100，默认 100
print(f"当前音量: {tts.get_volume()}")
tts.close()

# 上下文管理器写法（自动释放资源）
with tts:
    tts.speak("开始巡检")
```

---

### 16.2 VoiceSDK（完整功能）

**SDK 文件**：`robot_client/unitree_G1/agent_server/robot_sdk/voice_sdk.py`

在 `/code/execute` 内使用需先加 `sys.path`：

```python
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from robot_sdk.voice_sdk import VoiceSDK, quick_speak, VOICE_API
```

**VOICE_API 常量**（底层 API ID）：


| 常量                      | ID   | 用途           |
| ----------------------- | ---- | ------------ |
| `VOICE_API.TTS`         | 1001 | 文字转语音        |
| `VOICE_API.ASR`         | 1002 | 自动语音识别（机器人端） |
| `VOICE_API.PLAY_START`  | 1003 | 开始播放音频       |
| `VOICE_API.PLAY_STOP`   | 1004 | 停止播放音频       |
| `VOICE_API.GET_VOLUME`  | 1005 | 查询音量         |
| `VOICE_API.SET_VOLUME`  | 1006 | 设置音量         |
| `VOICE_API.SET_RGB_LED` | 1010 | 设置头部 LED 颜色  |


**初始化与生命周期**：

```python
# 方式 1：手动初始化
voice = VoiceSDK(iface="enp4s0", domain_id=0, timeout=10.0, enable_loco=True)
voice.initialize()          # 绑定网卡 → 激活 LocoClient → 初始化 AudioClient
# ... 使用 ...
voice.close()

# 方式 2：上下文管理器（推荐，自动 cleanup）
with VoiceSDK() as voice:
    voice.speak("你好")
```

**TTS 播报**：

```python
voice.speak("你好，我是 G1 机器人", speaker_id=0)
# speaker_id: 说话人 ID，默认 0
# 返回 0 表示成功，非 0 为错误码
```

**音量控制**：

```python
volume = voice.get_volume()  # 返回 int 0-100，或 None（失败）
voice.set_volume(100)        # 设置 0-100，超出范围自动 clamp，默认 100
```

**头部 LED 控制**：

```python
voice.set_led(0, 255, 0)    # R/G/B 各 0-255
```

**PCM 音频流**：

```python
code = voice.play_stream(pcm_data, app_name="voice_sdk", stream_id="0")
# pcm_data: bytes，PCM 原始音频数据
# 返回 0 成功

voice.play_stop(app_name="voice_sdk")
```

**一键播报（初始化→播报→释放）**：

```python
quick_speak("巡检完成", iface="enp4s0", speaker_id=0)
# 内部自动创建 VoiceSDK 实例，播报后立即释放资源
```

---

### 16.3 注意事项

1. **必须激活 G1 服务**：`enable_loco=True`（默认）会先初始化 `LocoClient`，TTS 依赖此步骤；跳过会导致 TTS 调用静默失败
2. **网卡绑定**：DDS 依赖正确的网卡（默认 `enp4s0`）；机器人 IP 网段为 `192.168.123.`*
3. **ROS1 导航**：`Nav2Anywhere` 基于 `rospy`（ROS1），内部自动 `init_node`；与 `VoiceSDK` 无依赖关系
4. **非线程安全**：每个进程只应创建一个 `VoiceSDK` 实例

---

## 15. 记忆写入规范（关键帧 / 语义 / 物体记忆）

> **用户指令**：写入关键帧或物体记忆时，**默认通过 D455 获取当前图像**（有特殊说明再用 D435i）。

### 15.1 标准写入流程

1. **获取 Lease** → `POST http://192.168.31.171:8888/lease/acquire`
2. **在机器人上执行代码** → `POST /code/execute` 用预注入 `camera` 对象获取 D455 画面
3. **Base64 编码图片** → 在机器人端编码，输出到 stdout
4. **本地构造 JSON** → 用 Python 构造包含 `robot_id`, `robot_pose`, `source`, `tags`, `note`, `image` 的 payload
5. **POST 到记忆系统** → `POST http://192.168.31.225:8022/memory/semantic/ingest`

### 15.2 标准命令模板

```bash
# Step 1: 获取 lease
curl -s -X POST http://192.168.31.171:8888/lease/acquire \
  -H "Content-Type: application/json" \
  -d '{"holder":"memory_ingest"}'

# Step 2: 在机器人上获取 D455 画面并 base64 编码（通过 /code/execute）
# 代码示例：
#   import cv2, base64
#   rgb, depth = camera.get_frame()
#   img_path = "/tmp/d455_frame.jpg"
#   cv2.imwrite(img_path, cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR))
#   with open(img_path, "rb") as f:
#       img_b64 = base64.b64encode(f.read()).decode("utf-8")
#   print("---B64_START---")
#   print(img_b64)
#   print("---B64_END---")

# Step 3: 在本地（OpenClaw host）构造 JSON 并写入记忆
python3 -c "
import base64, json, sys

# 读取从机器人获取的 base64 图片数据
# （实际使用时替换为从机器人 stdout 提取的 base64 字符串）
img_b64 = '...base64_data_from_robot...'

payload = {
    'robot_id': 'g1_001',
    'robot_type': 'unitree_g1',
    'robot_pose': {
        'x': 0.0, 'y': 0.0, 'z': 0.0,
        'roll': 0.0, 'pitch': 0.0, 'yaw': 0.0,
        'frame_id': 'map'
    },
    'source': 'd455_camera',
    'tags': ['keyframe', 'visual'],
    'note': 'D455 current frame',
    'image': img_b64
}

print(json.dumps(payload))
" | curl -s -X POST http://192.168.31.223:8022/memory/semantic/ingest \
  -H "Content-Type: application/json" \
  --data-binary @-
```

### 15.3 字段说明

| 字段 | 类型 | 说明 |
|------|------|------|
| `robot_id` | string | 机器人标识，如 `g1_001` |
| `robot_type` | string | 机器人类型，如 `unitree_g1` |
| `robot_pose` | object | 位姿 `{x, y, z, roll, pitch, yaw, frame_id}` |
| `source` | string | 数据来源标识 |
| `tags` | array | 标签数组，如 `['keyframe', 'visual']` |
| `note` | string | 文字备注 |
| `image` | string | Base64 编码的 JPEG/PNG 图像 |

### 15.4 注意事项

- **图片必须从机器人获取**：D455 画面在机器人端（`192.168.31.171`），OpenClaw host 无法直接访问摄像头
- **Base64 编码在机器人端完成**：避免跨网络传输原始图片文件
- **记忆系统地址**：`http://192.168.31.223:8022`（OpenClaw host 上的空间记忆服务）
- **语义记忆端点**：`/memory/semantic/ingest`（非 `/memory/keyframe/ingest-batch`）
- **关键帧批量端点**：如需使用 `ingest-batch`，格式为 `{"task_id": "...", "items": [...]}`

---

## 16. 其它

- Auth / API key：无（本地 loopback，不需要）
- Teleop fallback：未配置

