# AGENTS.md — Workspace Guide

## Session Startup

**每次新会话按顺序读：**

1. `SOUL.md` — 人格
2. `IDENTITY.md` — 你是谁
3. `MISSION.md` — 任务立场 + 决策流程
4. `USER.md` — 面前这个人
5. `ROBOT.md` — **硬规则唯一真相源**（调用路径 / 相机 / 预注入对象 / 错误协议 / 服务端口）
6. `TOOLS.md` — 本地环境（只有不在 ROBOT.md 里的东西才放这里）

**执行机器人任务前必须走的发现流程（详见 `MISSION.md`）：**

- `GET http://localhost:8888/code/sdk/modules` — 看预注入对象列表
- `GET http://localhost:8888/code/sdk/markdown` — 看方法签名

> 注意：SDK 文档路径是 `/code/sdk/markdown`，**不是** `/docs/guide/html`（后者是 ROS 驱动层文档）。

---

## Memory

- **每日原始日志**：`memory/YYYY-MM-DD.md`
- **长期精选记忆**：`memory/summary.md`（如不存在可创建；主会话维护）
- **规则**：写下来。记忆不跨重启。
- **机器人空间记忆（地点 / 物体）**：走 `memory.query_place()` / `memory.upsert_place()` 或直接 `POST http://localhost:8022/*`，详见 `ROBOT.md §5`。

---

## Boundaries

- 私人数据留在私人
- 外部动作（发邮件 / 对机器人下硬件指令 / 远程控制）**先问再做**
- 删文件用 `trash`，不要用 `rm`
- 不要在 `/code/execute` 里做越权的事（详见 `ROBOT.md §2` 安全层规则）

---

## Tooling

- **Skill 定义"工具怎么用"** → 在 `skills/<skill-name>/SKILL.md`
- **本地环境注释**（相机地址 / SSH / 网卡）→ 在 `TOOLS.md`
- **硬规则（调用路径 / 安全 / 相机绑定）** → 在 `ROBOT.md`

---

## Heartbeats (Optional)

如果有外部触发器（cron / systemd）定时喂 `Read HEARTBEAT.md. Follow strictly. If nothing needs attention, reply HEARTBEAT_OK.`：

- 按 `HEARTBEAT.md` 走
- 当前**未配置**定时器——若长期不用可删 `HEARTBEAT.md`

---

## Safety

- 不要外泄私人数据
- 不执行破坏性命令（包括机器人控制）前先确认
- 拿不准就问

---

_Living document. 学到新东西就更新。硬规则变化优先改 `ROBOT.md`，别的文件跟着引用即可。_
