# ROBOT.md 深度解析记忆
# 时间: 2026-04-22 16:50 GMT+8
# 来源: /home/ubuntu/.openclaw/workspace/ROBOT.md
# 重要性: 硬规则唯一真相源，每次会话必读

---

## 1. 编队端点状态

| 机器人 | Base URL | SDK 文档 | 状态 |
|---|---|---|---|
| Piper | `<PIPER_BASE_URL>` | `/code/sdk/markdown` | ❌ 未配置 |
| **G1** | `http://localhost:8888` | `/code/sdk/markdown` | ✅ 已连接 |
| Go2 | `<GO2_BASE_URL>` | `/code/sdk/markdown` | ❌ 未配置 |

**关键**: `/docs/guide/html` 是 ROS 驱动层文档，**不是 SDK**。SDK 文档在 `/code/sdk/markdown`。

---

## 2. 调用路径选择（三级优先）⭐ 最核心规则

### 路由真相源查找顺序（遇到不认识的端点）

1. **ROBOT.md §2 Level 1 表格** — 人工精选短 HTTP 端点
2. **`GET http://localhost:8888/openapi.json`** — FastAPI 全量路由清单（机器可读 JSON）
3. **`GET http://localhost:8888/docs`** — Swagger UI（人可读）
4. 都没命中 → **停，按 §6 错误协议报告用户，不要猜路径**

### 两个维度的区别（关键！）

| 维度 | 回答什么问题 | 入口 |
|---|---|---|
| **Python 对象清单** | "我在 `/code/execute` 的代码里能用哪些变量/方法" | `GET /code/sdk/modules` + `GET /code/sdk/markdown` |
| **HTTP 路由清单** | "我在外部 curl 时能调哪些端点" | `GET /openapi.json` + `ROBOT.md §2 Level 1` |

**典型错误**:
- ❌ 把 lease 拼成 `POST /code/lease` → 正确是 `POST /lease/acquire`（独立 `/lease/*` 命名空间）
- ❌ 把 face 识别拼成 `POST /face/recognize_current` → 没这端点，复合动作走 `/code/execute` 用预注入 `face` 对象
- ❌ 从 `GET /code/sdk/*` 里找 HTTP 路由 → 那是 Python 对象清单，不含 HTTP 路由

---

### Level 1 — 单条 HTTP、短平快、不动长时间机体

**直接 `curl`，不写 `code_executions` 里的 Python**：

| 操作 | 端点 | 方法/说明 |
|---|---|---|
| 查服务活没活 | `GET /health` | — |
| 查机器人当前状态 | `GET /state` | — |
| 查当前位姿 | `GET /nav/current_pose` | 返回 x/y/z/yaw/qx/qy/qz/qw |
| 查 SDK 目录 | `GET /code/sdk/modules` | Python 对象清单 |
| 查 SDK 详细文档 | `GET /code/sdk/markdown` | 方法签名 |
| 查 memory 地点 | `POST http://localhost:8022/query/place` | `{"name":"<地点名>","n_results":1}` |
| 写入 memory 地点 | `POST http://localhost:8022/memory/place/upsert` | 含完整 6-DoF 位姿 |
| 租约申请 | `POST /lease/acquire` | `{"holder":"<your_name>"}` |
| 释放租约 | `POST /lease/release` | `{"lease_id":"<id>"}` |
| 代码急停 | `POST /code/stop` | — |
| 查执行结果 | `GET /code/result/<execution_id>` | 返回 status/exit_code/stdout/stderr |

**已从 Level 1 移除**: `POST /nav/to_pose` — 与「人脸识别、抓取」同属长时间占用机器人的行为，**默认走 Level 2**。

> 调试例外: `POST /nav/to_pose` 仍在 `openapi.json` 中，仅供人工 smoke/排障；**OpenClaw 任务编排默认不要用「先 curl 导航再等很久再 execute 人脸」**，否则极易出现 **lease 在空窗期过期**。

---

### Level 2 — 需要 lease 的复合任务（/code/execute）

**典型场景**:
- 导航到 map 位姿（含从 memory 查到坐标再走、再等到达）→ 用 **预注入 `Nav2Anywhere`**，与人脸写在同一段 `code` 里
- 人脸识别 / 读相机 / YOLO / 抓取 → 预注入 `face` / `camera` / `yolo` / `grasp_*`
- 有条件/循环/多步组合的 Python 逻辑

**不可拆的三步原子流程**:

```
Step A: POST /lease/acquire
        Body:    {"holder":"<your_task_name>"}
        Returns: {"lease_id":"<uuid>", ...}          ← 必须拿到真实 uuid

Step B: POST /code/execute
        Headers: X-Lease-Id: <Step A 返回的 uuid>    ← ★★★ 放 Header，不是 Body
                 Content-Type: application/json
        Body:    {"code":"<python字符串>", "timeout":<秒>}

Step C: POST /lease/release                        ← 必做！
        Headers: Content-Type: application/json
        Body:    {"lease_id":"<Step A 返回的同一 uuid>"}
```

**Step C 时机**: Step B 返回后（成功/超时/子进程报错）**以及**向用户汇报「任务完成」**之前**。

**失败/重试**: 若还要用同一 holder 再 acquire，也须先对旧 `lease_id` release（或等其过期），避免占租约导致后续 `acquire` 失败。

---

### Level 2 禁止动作（违反会被服务端拒）

- ❌ **跳过 Step A 直接打 Step B** → 返回 `{"detail":"Missing X-Lease-Id header"}`
- ❌ **伪造/猜测 `X-Lease-Id`**（如 `test-lease-123`、`abc`、旧会话的 uuid）→ 返回 `{"detail":"Invalid or expired lease"}`
- ❌ **把 `lease_id` 塞进 Body 而不是 Header** → 服务端只认 Header，Body 里的字段会被忽略
- ❌ **把 lease 端点拼成 `/code/lease`、`/execute/lease`** → 正确前缀是 `/lease/*`
- ❌ **持有 lease 跑完 `/code/execute` 却不调 `/lease/release`** → 占租约会导致他人 `acquire` 失败

---

### /code/execute 子进程内的硬约束

- ❌ **禁止 `import`**: requests, httpx, urllib, socket, subprocess, shutil, multiprocessing, pickle（被安全层拦）
- ❌ **禁止直接 `from robot_sdk.ik import ...`** → 用预注入 `grasp_target` 代替
- ✅ **可以 `from robot_sdk.navigation_sdk import Nav2Anywhere`**（任务内导航默认走此路径）
- ✅ **可以 `from geometry_msgs.msg import PoseStamped`**（ROS1/ROS2 通用）
- ❌ **不要 `import rclpy`** — G1 部署的是 **ROS1**，没有 `rclpy`
- ✅ 用**预注入对象**满足 90% 感知/操控需求

---

### 图片保存与 image 工具

- `/code/execute` 里拍照后若要用 OpenClaw 的 `image` 工具分析 → **必须保存到 workspace 目录**: `/home/slxy/.openclaw/workspace/`
- ❌ 保存到 `/tmp/` 或其他目录 → `image` 工具会拒绝访问

```python
import cv2
rgb, depth = camera.get_frame()
cv2.imwrite("/home/slxy/.openclaw/workspace/scene.jpg", cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR))
```

---

### 描述场景的首选方式

**优先在 `/code/execute` 里直接调 `vision.describe_current_frame()`**，一步完成拍照 + VL 描述。

```python
# ✅ 推荐（一步到位）
result = vision.describe_current_frame()
print(result)

# ✅ 自定义 prompt
result = vision.describe_current_frame(prompt="画面里有几个人？")
print(result)

# ❌ 不推荐（拍照 → 保存 → 退出 execute → image 工具 → 再看图，多一轮往返、容易 lease 过期）
```

---

### Level 3 — 只读发现

只做 GET、不改变机器人状态、不需要 lease:
- health、state、`/code/sdk/*`、`openapi.json`、ROS 文档等

**三级一眼表**:

| Level | 一句话 | 典型手段 | 会写 code_executions/*.py？ |
|:---:|:---|:---|:---:|
| **1** | 短 HTTP；不动长时间机体 | curl health / lease / query_place / GET current_pose | 否 |
| **2** | lease + 机体/感知/导航/脚本逻辑 | lease/acquire → /code/execute → lease/release | **是** |
| **3** | 只读 GET 发现 | curl -s GET ...、浏览器看 /docs | 否 |

---

## 3. /code/execute 预注入对象清单

**以下变量在子进程里已经是活的对象，直接用，不用 import**：

| 名字 | 类型 | 用途 | 关键细节 |
|---|---|---|---|
| `env` | `G1RobotEnv` | 组合门面 | 含 `env.read_cameras()` 等 |
| `camera` | D455 RGB-D | **水平朝前** | `rgb, depth = camera.get_frame()` → 返回 **tuple 不是 dict**；rgb: np.ndarray (H,W,3) uint8；depth: np.ndarray (H,W) float32（米） |
| `camera_d435i` | D435i RGB-D | **倾斜朝下** | 同上格式，**仅抓取用** |
| `yolo` | YoloSDK（lazy） | 物体检测 | `yolo.detect_on_rgb(rgb)`、`yolo.detect_env()`、`yolo.segment_3d(label)` |
| `face` | FaceSDK | 人脸识别 | `face.recognize_current_frame()` → 返回 dict，含 `results` 列表 |
| `memory` | MemorySDK | 空间记忆 | `memory.query_place(name)`、`memory.upsert_place(...)` |
| `tts` | TTS | 语音合成 | `tts.initialize()` → `tts.speak(text)` |
| `vision` | Kimi VL | 多模态场景描述 | `vision.describe_current_frame()` 或 `vision.describe(rgb, prompt="...")` → 返回**中文描述字符串** |
| `grasp_target(r_pos, l_pos)` | function | 精细抓取 | 坐标已知时使用 |
| `grasp_something(name)` | function | 一句话检测+抓取 | 失败返回 False |
| `release_object()` | function | 放下/松手 | 回 home + 打开灵巧手 |
| `Nav2Anywhere` | **class**（非实例） | 导航 | **ROS1** — SDK 内部自动 `rospy.init_node()`；`nav = Nav2Anywhere(); nav.nav_to_pose(pose); nav.wait_until_reached(timeout_sec=...)`；也支持 `nav.publish_simple_goal(x, y, yaw)` |
| `Pose` | class | 构造 memory 地点 | `memory_sdk.Pose` |

**不要假设其他名字存在**；不在上表里的都当不存在，先走 `GET /code/sdk/modules` 确认。

---

## 4. 相机绑定规则（CRITICAL）

**铁律：违反会看错视角 / 数错人 / 抓偏。**

| 相机 | 安装 | 视野 | **唯一用途** | 对应对象 |
|---|---|---|---|---|
| **D455** | 头部，**水平朝前** | 站立的人 / 场景 / 远景 | 人脸识别 + **其它一切朝前视觉** | `camera` / `env.camera` / `face` |
| **D435i** | 手臂附近，**倾斜朝下** | 手下方 / 桌面 | **仅抓取**（且抓取**必须**用它） | `camera_d435i` / `yolo.detect_env()` / `yolo.segment_3d(...)` |

### 硬选择规则

| 任务 | 用哪个调用 | 相机 |
|---|---|---|
| 画面里有几个人 / 都是谁 | `face.recognize_current_frame()` | D455 |
| 画面里有什么物体（非抓取） | `rgb, _ = camera.get_frame(); yolo.detect_on_rgb(rgb)` | D455 |
| 抓取前找桌面物体 | `yolo.detect_env()` 或 `yolo.segment_3d("bottle")` | D435i |
| 执行抓取 | `grasp_target(...)` / `grasp_something(name)` | D435i |
| 导航到 map 位姿（含等到达） | **`/code/execute` + `Nav2Anywhere`**（Level 2） | — |

**永远不要用 `yolo.detect_env()` 去数站立的人**——它内部绑 D435i，视野偏地面，看不到站着的人。

---

## 5. 空间记忆使用规则

从空间记忆取位姿后，**必须使用完整 6-DoF 信息**：
- **position**: x, y, z
- **orientation**: qx, qy, qz, qw（四元数）

`memory.query_place()` 返回的 `target_pose` 是**扁平结构**：

```json
{
  "x": ..., "y": ..., "z": ...,
  "roll": ..., "pitch": ..., "yaw": ...,
  "qx": ..., "qy": ..., "qz": ..., "qw": ...,
  "frame_id": "map"
}
```

**禁止**:
- ❌ 只取 x/y 忽略朝向，自己填 qw=1.0
- ❌ 假设有 `target_pose["orientation"]` 这种嵌套层（**没有**，是扁平的）
- ❌ 用不完整的姿态发起导航（无论 `Nav2Anywhere` 还是调试用的 `POST /nav/to_pose`）

---

## 6. 错误处理协议（CRITICAL）

**遇到错误/异常时的正确行为**：

1. **立即 STOP**——不要自动重试 / 绕过 / 改代码
2. **SUMMARIZE**——总结问题（一两句话 + 具体错误消息）
3. **REPORT**——把问题报给用户
4. **WAIT**——等用户指示再继续

**禁止行为**:
- ❌ 自动重试失败的操作
- ❌ 擅自尝试替代方案
- ❌ 猜测原因并修改代码 / 配置
- ❌ 出错后仍然继续下一步

**典型正确回应**:
> "遇到以下问题：`[简短总结]`。具体错误：`[错误消息 / 日志]`。请问你希望如何处理？"

---

## 7. 时间限制（/code/execute 超时）

- **硬超时**由 `/code/execute` 请求体的 `"timeout": <秒>` 控制（默认 300s）
- Lease 的 idle timeout（默认 60s）是**空闲超时**——衡量"无新命令 / 无关节运动"，不是"任务必须在 60s 内完成"
- 用户说"必须 60s 内完成"→ **必须** 在 JSON body 里带 `"timeout": 60`，嘴上说不算

---

## 8. 服务端口（实测 2026-04-20）

| 服务 | URL | 状态 |
|---|---|---|
| G1 agent_server | `http://localhost:8888` | ✅ |
| G1 YOLO | `http://localhost:8013` | ✅（cuda:0, yolov5l6） |
| G1 Face | `http://localhost:8016` | ✅（buffalo_l） |
| G1 Spatial Memory | `http://localhost:8022` | ✅（本地 SQLite） |
| G1 D455 RGB (ZMQ) | `tcp://192.168.123.164:5555` | ✅ |
| G1 D435i (TCP) | `192.168.123.164:8765` | ✅ |
| Piper | — | ❌ 未配置 |
| Go2 | — | ❌ 未配置 |

- `enp4s0` 网卡 IP = `192.168.123.199`，只在**对机器人网段**通信时相关
- 对 OpenClaw 自身服务（agent_server / memory / yolo / face），**一律用 `localhost`**

---

## 9. 安全 / E-stop

- **硬件 E-stop**: G1 本体红色急停按钮
- **软件急停**: `POST http://localhost:8888/lease/release`（释放租约 → 当前执行被中止）
- **代码级停止**: `POST http://localhost:8888/code/stop`
- **异常后先退租约再报告**——避免占住机器人
- G1 质量大、力矩高；运动前确认 **1.5m 无人**；抓取前确认工作面清空
- **没有仿真兜底**——真机直接执行

---

## 10. Skill Template

每个 skill 必须声明：
1. **Target robot**（Piper / G1 / Go2）
2. **Sensor/actuator assumptions**——显式说明用 D455 还是 D435i
3. **调用路径**——走 Level 1 HTTP / Level 2 `/code/execute` / 混合
4. **Safety checks**——lease 获取 / E-stop 预案 / 活动范围确认
5. **Supervision required?**——是否需要人盯着

---

## 11. 连接状态摘要（2026-04-20）

- ✅ **G1**: 本地连接正常，具备视觉（D455+D435i）、YOLO、Face、TTS、空间记忆、ROS2 导航
- ❌ Piper: 未配置端点
- ❌ Go2: 未配置端点

---

## 12. 其它

- Auth / API key: 无（本地 loopback，不需要）
- Teleop fallback: 未配置

---

## 核心要点总结

1. **硬规则唯一真相源**: MISSION.md / TOOLS.md / AGENTS.md 提到的机器人规则，以 ROBOT.md 为准
2. **三级调用路径是核心**: Level 1（短 HTTP）→ Level 2（lease + execute）→ Level 3（只读发现）
3. **相机绑定铁律**: D455 水平朝前（人脸识别/场景），D435i 倾斜朝下（仅抓取）
4. **空间记忆完整 6-DoF**: 必须用 x,y,z,qx,qy,qz,qw，扁平结构
5. **错误处理四步**: STOP → SUMMARIZE → REPORT → WAIT
6. **Lease 原子流程**: acquire → execute → release，不可拆
7. **安全第一**: 没有仿真，1.5m 无人，先退租约再报告
8. **预注入对象**: 满足 90% 需求，不要瞎 import
