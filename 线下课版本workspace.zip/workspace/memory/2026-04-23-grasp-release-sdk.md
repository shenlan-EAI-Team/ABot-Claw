# G1 抓取与释放 SDK 正确用法
# 时间: 2026-04-23 11:55 GMT+8
# 来源: /home/ubuntu/AbotClaw4.22ws/szm14.22/szm1/ABot-Claw/robot_client/unitree_G1/agent_server/robot_sdk/

---

## 抓取瓶子 - 使用 grasp_something_sdk.py

### 文件位置
`/home/ubuntu/AbotClaw4.22ws/szm14.22/szm1/ABot-Claw/robot_client/unitree_G1/agent_server/robot_sdk/grasp_something_sdk.py`

### 对外接口
```python
grasp_something(
    object_name: str,                    # 目标类别名，例如 "bottle"
    *,
    robot_ip: Optional[str] = None,      # 灵巧手所在机器人 IP
    detection_index: int = 0,            # 多目标时按置信度排序后选取的索引
    right_target_offset: Optional[Sequence[float]] = None,  # 可选右手抓取偏移
    log_dir: Optional[str | Path] = None,  # 检测图保存目录，默认 agent_server/logs
) -> bool
```

### 封装流程
1. YOLO 检测指定目标（通过 D435i）
2. 保存一张当前检测图到 agent_server/logs
3. 根据检测结果执行抓取（调用 grasp_target）
4. 结束后回到 home 位并释放控制权

### 使用示例
```python
from robot_sdk.grasp_something_sdk import grasp_something

# 抓取瓶子
success = grasp_something("bottle")

# 抓取特定索引的瓶子（多目标时）
success = grasp_something("bottle", detection_index=1)

# 指定机器人 IP
success = grasp_something("bottle", robot_ip="192.168.123.164")

# 指定日志目录
success = grasp_something("bottle", log_dir="/tmp/grasp_logs")
```

### 预注入对象
在 `/code/execute` 子进程中，直接使用预注入的 `grasp_something`：
```python
# 不需要 import，直接使用
success = grasp_something("bottle")
```

---

## 放下瓶子 - 使用 release_something_sdk.py

### 文件位置
`/home/ubuntu/AbotClaw4.22ws/szm14.22/szm1/ABot-Claw/robot_client/unitree_G1/agent_server/robot_sdk/release_something_sdk.py`

### 对外接口
```python
release_something(
    *,
    robot_ip: Optional[str] = None,  # 灵巧手所在机器人 IP
) -> bool
```

### 封装流程
1. 执行放置/松手序列（home → lift → 固定放置位 → 灵巧手松开 → 回撤）
2. 结束后回到 home 位并释放控制权

### 使用示例
```python
from robot_sdk.release_something_sdk import release_something

# 放下物体
success = release_something()

# 指定机器人 IP
success = release_something(robot_ip="192.168.123.164")
```

### 预注入对象
在 `/code/execute` 子进程中，直接使用预注入的 `release_object`（注意：预注入的是 `release_object`，不是 `release_something`）：
```python
# 预注入的是 release_object
release_object()

# 如果需要使用 release_something，需要显式导入
from robot_sdk.release_something_sdk import release_something
release_something()
```

---

## 关键区别

| 功能 | 预注入对象 | SDK 文件 | 说明 |
|:---|:---|:---|:---|
| 抓取 | `grasp_something` | `grasp_something_sdk.py` | 检测+抓取一体化 |
| 释放 | `release_object` | `release_something_sdk.py` | 注意名称不同！|

**重要**：预注入的是 `release_object`（来自 `g1_grasp_sdk.py`），不是 `release_something`（来自 `release_something_sdk.py`）。

---

## 完整任务示例

```python
# 抓取瓶子
success = grasp_something("bottle")
if success:
    print("抓取成功！")
    
    # 导航到目标位置...
    
    # 放下瓶子
    release_object()  # 使用预注入的 release_object
else:
    print("抓取失败")
```

---

## 注意事项

1. **grasp_something 依赖 AnyGrasp 服务**（端口 8015）
2. **release_object 依赖 RobotBridge**（DDS 通信）
3. 两者都需要正确的机器人 IP 和网络配置
4. 抓取前确保 D435i 相机可用
5. 释放前确保机械臂处于安全位置
