# 长期精选记忆

> 硬规则见 `ROBOT.md`（每次会话必读）。本文件只存 ROBOT.md 里没有的跨会话信息。

---

## 1. 舰队配置

| 机器人 | 状态 | Base URL | 传感器/能力 |
|--------|------|----------|-------------|
| **G1** | ✅ 可用 | `http://localhost:8888`（agent_server） | D455(前视) + D435i(下视) + YOLO + Face + TTS + Nav2 + Memory |
| Piper | ❌ 未配置 | 待填 | — |
| Go2 | ❌ 未配置 | 待填 | — |

---

## 2. G1 服务端口

| 服务 | 端口 | 说明 |
|------|------|------|
| agent_server | 8888 | lease / code/execute / health / state / nav / cameras / tts |
| YOLO | 8013 | 物体检测（yolov5l6, cuda:0） |
| Face | 8016 | 人脸识别（buffalo_l） |
| Memory | 8022 | 空间记忆（本地 SQLite） |
| AnyGrasp | 8015 | 抓取规划 |

---

## 3. 网络拓扑

- 本机 OpenClaw 服务：均通过 `localhost` 访问
- G1 传感器推流：方向待确认（`ROBOT.md` 与 `TOOLS.md` IP 不一致，需核实）
- `enp1` 网卡：`192.168.123.99`

---

## 4. 用户信息

- **Name:** 待填写
- **Timezone:** Asia/Shanghai (UTC+8)

---

## 5. 历史教训（实测经验，非规则复述）

- **2026-05-06**: G1 本体与 agent_server 之间有 ROS2 桥接层，`state` 返回 `connected: false` 不一定代表物理不通——可能是 DDS 通信层问题，需要检查桥接节点是否启动
- **2026-05-06**: TTS 需显式 `tts.initialize()` 后才能 speak；音量需单独 `set_volume(100)` 设置
- **2026-05-06**: G1 IP 地址在五一假期前后多次变更（从 `192.168.123.164` 到 `192.168.31.152` 到 `192.168.31.171`），每次变更都要同步改 ROBOT.md
- **2026-04-29**: openclaw.json 配置曾多次被 OpenClaw 自身标记为 invalid 并自动回滚（config-audit.jsonl 有记录），疑似与 gateway 启动参数冲突有关

---

## 6. 本地技能（仅列出，实际用时可读）

- `abotclaw-sdk-discovery` — 发现机器人真实用法
- `abotclaw-run-robot-task` — 执行物理任务
- `abotclaw-memory` — 空间记忆
- `abotclaw-bundle` — 打包技能

---

## 更新历史

- **2026-05-07**: 重写为精简版，去除 ROBOT.md 规则复述；仅保留跨会话实际记忆
