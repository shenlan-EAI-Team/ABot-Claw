# 2026-05-21 — G1 导航 SDK 重大更正：ROS1 而非 ROS2

## 发现

读取实际 SDK 源码后确认：
- **文件**: `/home/xxuz/docker_abotclaw/robot/abotclaw_g1_workspace/robot_client/unitree_G1/agent_server/robot_sdk/navigation_sdk.py`
- **实现**: **ROS1**（`rospy`, `tf.TransformListener`, `actionlib.SimpleActionClient`）
- **之前记忆错误**: 一直以为需要 `rclpy.init()`（ROS2），实际是 ROS1

## 正确用法

### 方式一：简单下发（fire-and-forget，推荐）
```python
nav = Nav2Anywhere()
nav.publish_simple_goal(x=0.47, y=-0.26, yaw=2.57)
# 立即返回，不等待到达
```

### 方式二：Action 等待到达
```python
from geometry_msgs.msg import PoseStamped

nav = Nav2Anywhere()
# nav_to_pose 内部自动 init_node（单进程只 init 一次）
nav.nav_to_pose(pose_stamped)
reached = nav.wait_until_reached(timeout_sec=180.0)
```

**不需要手动 `import rospy; rospy.init_node()`** —— SDK 构造函数内部已处理。

## 关键区别

| 项目 | 旧（错误）记忆 | 正确（ROS1） |
|---|---|---|
| 初始化 | `rclpy.init()` | **SDK 内部自动 `rospy.init_node()`** |
| 等待到达机制 | 等 `/navigation_reached` topic | **move_base action** (`/move_base/move_base`) |
| 简单下发 | 无此 API | **`publish_simple_goal(x, y, yaw)`** |
| TF 查询 | `rclpy` 方式 | **`tf.TransformListener`** |

## 为什么之前 `/code/execute` 里 `import rclpy` 失败

因为 G1 部署的是 **ROS1 Noetic**（或 Melodic），根本没有 `rclpy` 包。应该用 `rospy`。

## 待验证

- [ ] 在 `/code/execute` 里直接用 `Nav2Anywhere()` 不手动 init 是否能正常工作
- [ ] `nav_to_pose` + `wait_until_reached` 在 `/code/execute` 子进程里是否能正常连接 move_base action server
