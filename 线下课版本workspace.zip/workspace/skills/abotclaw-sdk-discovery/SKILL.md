---
name: abotclaw-sdk-discovery
description: Discover how a robot is actually used by reading its deployed guide and SDK reference before writing code. Use when starting robot work, when the API is unclear, when a new robot is added, or when OpenClaw must determine the real robot usage pattern instead of guessing.
---

# AbotClaw SDK Discovery

This skill owns one question:

**How should OpenClaw discover the real usage pattern of a robot before writing code?**

## Responsibility Boundary

This skill is the single place for:

- finding the robot base URL
- querying the robot guide
- querying the robot SDK reference
- summarizing how the robot is actually used

Other files should reference this skill instead of duplicating SDK discovery instructions.

## Default Discovery Path

For AbotClaw, discovery should start from known service and robot configuration, not from broad local searching.

This is a runtime introspection flow:

- OpenClaw starts from the robot `Base URL`
- the robot's deployed guide explains the operational entrypoints
- the robot's deployed SDK reference explains the callable runtime methods
- only after reading both should OpenClaw decide how control actually works

Use this order:

1. read `SERVICE.md`
2. read `ROBOT.md`
3. identify the correct robot base URL
4. query the getting-started guide
5. query the SDK reference
6. summarize the discovered usage pattern
7. only then write code

## Canonical Queries

### 1. Getting-started guide

```bash
curl -s -L <ROBOT_BASE_URL>/docs/guide/html
```

Use this guide to discover things like:

- whether the robot expects `POST /code/execute`
- whether a lease or token is required
- what request payload shape is expected
- what the safest first command path is

### 2. SDK reference

```bash
curl -s -L <ROBOT_BASE_URL>/code/sdk/markdown
```

Use this SDK reference to discover things like:

- what runtime objects or SDK clients exist
- which methods expose motion, camera, or gripper control
- whether objects are pre-injected by the execution wrapper
- what a minimal valid code example looks like

### 3. Optional health check

If the deployment exposes a health endpoint, check it before deeper calls:

```bash
curl -s <ROBOT_BASE_URL>/health
```

## What to Extract

Before writing robot code, determine:

- how to connect
- how to read cameras
- how to read robot pose/state
- how to send actions or commands
- whether the guide advertises code execution or another control path
- whether auth, lease, or session state is required
- how to stop safely
- what the smallest safe smoke test should be

## Code Execution Rule

If the guide confirms `POST /code/execute` exists, that is the **only** control path.

All perception and control operations — taking photos, face recognition, object detection, navigation, arm movement, memory queries — must be written as Python code and submitted via `POST /code/execute`. The execution wrapper pre-creates SDK objects (like `env`, `face`, `yolo`, `memory`). Your submitted code contains **only business logic**: no imports, no SDK initialization.

Do not directly call the robot's HTTP endpoints (like `GET /camera/rgb.jpg` or external service APIs like `POST <face_service>/face/recognize`) from outside. Those endpoints exist for the SDK internals or for monitoring — they are not your control interface.

What you **can** call directly (without code execution):

- `GET /health` — connectivity check
- `GET /state` — read-only robot state
- `POST /lease/acquire`, `POST /lease/release` — lease management
- `GET /code/status`, `GET /code/result` — execution monitoring

Everything else goes through submitted code.

## Discovery Sources

Only use these two endpoints to learn about a robot:

1. `<ROBOT_BASE_URL>/docs/guide/html` — the deployed getting-started guide
2. `<ROBOT_BASE_URL>/code/sdk/markdown` — the deployed SDK reference

Do not use `/openapi.json`, `/docs` (Swagger UI), or any other auto-generated schema as a discovery source. Those list all HTTP endpoints without operational context, which leads to calling endpoints directly instead of going through code execution.

## Deliverable

Before writing code, summarize the real usage pattern in plain terms.

A good summary should answer:

- what is the correct base URL?
- what did the deployed guide reveal about the control route?
- what SDK objects are pre-injected by the wrapper?
- which SDK method handles my task (e.g. `face.recognize_current_frame()`)?
- what does a minimal submitted code snippet look like?
- how do I acquire and release a lease?
- how do I stop safely?

## Fallback Rule

Only use broader fallback sources when the guide or SDK reference is missing or clearly incomplete.

Fallback sources may include:

- vendor docs
- existing deployment examples
- operator-provided notes

Do not treat those as the default path.

## Rule

Do not invent methods because they sound plausible. If the deployed docs do not show a method, treat it as unknown until confirmed.

Do not assume `/code/execute`, injected runtime objects, or any specific SDK method until the deployed guide or SDK reference explicitly shows them.
