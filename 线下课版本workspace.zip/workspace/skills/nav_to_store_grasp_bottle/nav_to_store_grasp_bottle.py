#!/usr/bin/env python3
"""
导航到便利店并抓取瓶子

使用方法:
1. 获取租约: POST /lease/acquire
2. 执行此代码: POST /code/execute (带 X-Lease-Id header)
3. 释放租约: POST /lease/release

预注入对象:
- Nav2Anywhere: 导航
- grasp_something: 抓取物体
"""

import rclpy
from geometry_msgs.msg import PoseStamped
from robot_sdk.navigation_sdk import Nav2Anywhere
import time

rclpy.init()
nav = Nav2Anywhere()

# 目标：便利店
target_x = 1.5833535148193738
target_y = -1.2411990792259906
target_z = -0.1776551091384383

pose = PoseStamped()
pose.header.frame_id = "map"
pose.pose.position.x = target_x
pose.pose.position.y = target_y
pose.pose.position.z = target_z
pose.pose.orientation.x = -0.011366138767518892
pose.pose.orientation.y = -0.00558340096096245
pose.pose.orientation.z = 0.9839828640601114
pose.pose.orientation.w = 0.17781270977994554

print("=== 阶段1: 导航到便利店 ===")
nav.nav_to_pose(pose)
reached = nav.wait_until_reached(timeout_sec=120)
print("导航到达结果:", reached)

if reached:
    print("\n=== 阶段2: 等待稳定 ===")
    time.sleep(2)
    
    print("\n=== 阶段3: 抓取瓶子 ===")
    result = grasp_something("bottle")
    print("抓取结果:", result)
    
    if result:
        print("✅ 成功抓取瓶子")
    else:
        print("❌ 抓取失败")
else:
    print("❌ 导航失败，跳过抓取")

print("\n任务完成")
