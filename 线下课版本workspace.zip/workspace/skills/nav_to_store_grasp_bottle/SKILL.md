# nav_to_store_grasp_bottle - 导航到便利店并抓取瓶子

## 功能

导航到便利店位置，然后使用 YOLO + 机械臂抓取面前的瓶子。

## 使用方法

### 1. 获取租约

```bash
curl -s -X POST http://192.168.31.171:8888/lease/acquire \
  -H "Content-Type: application/json" \
  -d '{"holder":"nav_store_grasp"}'
```

### 2. 执行代码

```bash
curl -s -X POST http://192.168.31.171:8888/code/execute \
  -H "Content-Type: application/json" \
  -H "X-Lease-Id: <lease_id>" \
  -d '{"code":"<python代码>","timeout":180}'
```

### 3. 释放租约

```bash
curl -s -X POST http://192.168.31.171:8888/lease/release \
  -H "Content-Type: application/json" \
  -d '{"lease_id":"<lease_id>"}'
```

## 代码文件

- **主代码**: `nav_to_store_grasp_bottle.py`

## 执行流程

1. **导航阶段** - 使用 Nav2Anywhere 导航到便利店坐标
2. **稳定阶段** - 等待 2 秒让机器人稳定
3. **抓取阶段** - 使用 grasp_something("bottle") 执行抓取

## 预注入对象

| 对象 | 用途 |
|------|------|
| `Nav2Anywhere` | ROS2 导航 |
| `grasp_something(name)` | 检测+抓取一体化 |

## 目标坐标

| 参数 | 值 |
|------|-----|
| x | 1.5833535148193738 |
| y | -1.2411990792259906 |
| z | -0.1776551091384383 |

## 成功记录

- **2026-05-08 21:17** - 导航成功 + 抓取成功
  - YOLO 检测到瓶子坐标: Torso X=0.223, Y=0.153, Z=-0.166
  - 抓取序列: home → lift → target → grasp → lift → home
  - 耗时: ~48 秒

## 注意事项

- 导航超时: 120 秒
- 到达后等待 2 秒再抓取
- 抓取使用 D435i 相机（朝下）检测瓶子
- 如果便利店位置有变化，需要更新坐标
