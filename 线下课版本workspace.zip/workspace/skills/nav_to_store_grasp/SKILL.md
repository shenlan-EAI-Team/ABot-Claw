# nav_to_store_grasp - 导航到便利店并抓取瓶子

## 功能

导航到便利店位置，然后尝试抓取面前的瓶子。

## 使用方法

此技能需要在 `/code/execute` 中执行，使用预注入对象。

### 代码

```python
import rclpy
from geometry_msgs.msg import PoseStamped
from robot_sdk.navigation_sdk import Nav2Anywhere
import time

rclpy.init()
nav = Nav2Anywhere()

# 目标：便利店
target_x = 1.5833535148193738
target_y = -1.2411990792259906
target_z = -0.1776551091384383

pose = PoseStamped()
pose.header.frame_id = "map"
pose.pose.position.x = target_x
pose.pose.position.y = target_y
pose.pose.position.z = target_z
pose.pose.orientation.x = -0.011366138767518892
pose.pose.orientation.y = -0.00558340096096245
pose.pose.orientation.z = 0.9839828640601114
pose.pose.orientation.w = 0.17781270977994554

print("=== 阶段1: 导航到便利店 ===")
nav.nav_to_pose(pose)
reached = nav.wait_until_reached(timeout_sec=120)
print("导航到达结果:", reached)

if reached:
    print("\n=== 阶段2: 等待稳定 ===")
    time.sleep(2)
    
    print("\n=== 阶段3: 抓取瓶子 ===")
    result = grasp_something("bottle")
    print("抓取结果:", result)
    
    if result:
        print("✅ 成功抓取瓶子")
    else:
        print("❌ 抓取失败")
else:
    print("❌ 导航失败，跳过抓取")

print("\n任务完成")
```

## 执行流程

1. **获取租约** - `POST /lease/acquire`
2. **执行代码** - `POST /code/execute` (带 `X-Lease-Id` header)
3. **释放租约** - `POST /lease/release`

## 注意事项

- 导航超时设置为 120 秒
- 到达后等待 2 秒稳定再抓取
- 抓取使用 D435i 相机（朝下）检测瓶子
- 如果便利店位置有变化，需要更新坐标

## 历史记录

- 2026-05-08: 导航成功到达，但抓取失败（未检测到瓶子）
