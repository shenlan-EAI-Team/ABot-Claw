---
name: abotclaw-memory
description: SpatialMemoryHub-based robot memory querying, writing, and retrieval for AbotClaw. Use when the agent needs to store or retrieve object memory, place memory, keyframe memory, or semantic frame memory; when checking whether a memory service is running; when using robot SDK camera frames to perform memory ingestion or memory-guided retrieval; or when grounding robot tasks in prior visual/spatial experience.
---

# AbotClaw Memory

Use this skill whenever robot behavior should rely on remembered places, objects, visual evidence, or past observations.

## What This Memory Module Is

SpatialMemoryHub is a unified robot memory service. It supports four memory types:

1. **object memory** — concrete detected objects with pose and evidence
2. **place memory** — named semantic places and anchors
3. **keyframe memory** — offline extracted keyframes for large-scene memory building
4. **semantic frame memory** — image memories retrievable by text semantics

## Service Location

Assume the SpatialMemoryHub server is already running.

Get the correct host and port from `service.md`.

This skill is about **using** the memory service, not deploying it.

## Always Check Health First

Before relying on memory, check if the service is running (via HTTP or in code):

```python
# In submitted code via /code/execute
health = memory.health()
print(health)  # {"status": "ok", ...}
```

Or via HTTP:
```bash
curl -s <MEMORY_BASE_URL>/health
```

If the service is not healthy, do not pretend memory is available.

## ⚠️ Critical: How to Use Memory

**DO NOT use curl/bash for memory operations in robot tasks.**

All memory operations must go through the **pre-injected `memory` object** via `/code/execute`:

```python
# ✅ Correct: Use pre-injected memory object in submitted code
results = memory.query_place("厨房")
memory.upsert_place(place_name="205会议室", ...)
```

```bash
# ❌ Wrong: Do NOT use curl for memory operations in robot tasks
curl -X POST <MEMORY_BASE_URL>/query/place ...
```

The `memory` object is already configured with the correct service URL and handles errors gracefully.

## Core API Methods (via pre-injected `memory` object)

### Write methods
- `memory.upsert_object(...)` — save detected object
- `memory.upsert_place(...)` — save named location
- `memory.insert_object(...)` — alias for upsert_object

### Query methods
- `memory.query_object(name, n_results=5)` — find objects by name
- `memory.query_place(name, n_results=10)` — find places by name
- `memory.health()` — check service status



## Unified Result Shape

All retrieval results should be read as navigation-usable memory hits. Expect fields such as:

- `memory_type`
- `target_pose`
- `confidence`
- `evidence`

## How to Query Memory (via /code/execute)

### Object memory

Use when the user asks things like:
- where is the cup?
- have you seen the remote?

**In submitted code via `/code/execute`:**
```python
results = memory.query_object("cup", n_results=5)
for r in results:
    print(f"{r['name']} at {r['target_pose']}")
```

### Place memory

Use when the user asks:
- where is the kitchen?
- go to the tool table

**In submitted code via `/code/execute`:**
```python
results = memory.query_place("厨房", n_results=5)
if results:
    target = results[0]["target_pose"]
    print(f"Found: x={target['x']:.2f}, y={target['y']:.2f}")
```

### Position radius query

Use when retrieving memory near a known point:
```python
# Via HTTP API (for debugging or external tools)
import requests
resp = requests.post(f"{memory._base_url}/query/position", json={
    "x": 1.0, "y": 2.0, "radius": 2.5
})
print(resp.json())
```

### Semantic text query

Use when the user describes a scene or object naturally:
```python
# Via HTTP API (for debugging or external tools)
import requests
resp = requests.post(f"{memory._base_url}/query/semantic/text", json={
    "text": "a table with bottles and tools"
})
print(resp.json())
```

### Unified query

Use when multiple memory types may help:
```python
# Via HTTP API (for debugging or external tools)
import requests
resp = requests.post(f"{memory._base_url}/query/unified", json={
    "text": "cup near kitchen table"
})
print(resp.json())
```

## How to Write Memory (via /code/execute)

### Object memory upsert

Use after visual detection plus pose estimation:

**In submitted code via `/code/execute`:**
```python
from robot_sdk.memory_sdk import Pose

result = memory.upsert_object(
    object_name="cup",
    robot_id="g1_001",
    robot_type="humanoid",
    robot_pose=Pose(x=1.0, y=1.0),  # robot position when observing
    object_pose=Pose(x=1.2, y=1.1, z=0.8),  # object position
    detect_confidence=0.93
)
print(f"Saved: {result}")  # {"ok": True, "id": "..."}
```

### Place memory upsert

Use after human labeling or semantic anchoring:

**In submitted code via `/code/execute`:**
```python
from robot_sdk.memory_sdk import Pose

result = memory.upsert_place(
    place_name="厨房",
    robot_id="g1_001",
    robot_type="humanoid",
    place_pose=Pose(x=4.0, y=2.0, yaw=1.57),
    note="厨房门口"
)
print(f"Saved: {result}")  # {"ok": True, "id": "plc_..."}
```

### Semantic frame ingest

Use after obtaining an image plus note/tags (via HTTP API):
```python
# Via HTTP API (for external batch ingestion)
import requests
resp = requests.post(f"{memory._base_url}/memory/semantic/ingest", json={
    "robot_id": "go2_001",
    "robot_type": "quadruped",
    "note": "workbench with red screwdriver and black toolbox",
    "tags": ["workbench", "tools"]
})
print(resp.json())
```

## Robot SDK + Camera + Memory Workflow

Memory often requires live camera frames or robot pose. These operations must go through the robot's code execution path, not direct HTTP calls.

### Standard workflow

1. Use `abotclaw-sdk-discovery` to learn the robot's SDK methods for camera, pose, and memory.
2. Write Python code that uses the pre-injected SDK objects (`env`, `memory`) in a single script.
3. Submit that code via `POST /code/execute` — do not curl any endpoints directly.
4. Inside the submitted code: use `env` for camera/pose, use `memory` for reading/writing memory entries.
5. Later, query memory the same way — through `memory` object in submitted code.

### Required rule

All memory operations must go through the pre-injected `memory` object via code execution, not direct HTTP calls to SpatialMemoryHub. The `memory` object is already configured with the correct service URL.

Do not invent camera or memory methods. Discover them first via `abotclaw-sdk-discovery`.

### Deprecated: env.remember_location / env.navigate_to_location

These methods have been removed. All location memory is now handled by `memory.upsert_place()` / `memory.query_place()` through SpatialMemoryHub.

To navigate to a remembered place, query it first, then use `env.navigate_to()`:

```python
results = memory.query_place("厨房")
if results:
    tp = results[0]["target_pose"]
    env.navigate_to(x=tp["x"], y=tp["y"], theta=tp.get("yaw", 0))
```

### Example: Save current position as a place

```python
from robot_sdk.memory_sdk import Pose

pose = env.get_robot_pose()
loc = pose.get("localization", {})
memory.upsert_place(
    place_name="厨房",
    robot_id="g1_001",
    robot_type="humanoid",
    place_pose=Pose(x=loc["x"], y=loc["y"], yaw=loc.get("yaw", 0)),
    note="厨房门口",
)
```

## Typical Memory-Driven Behaviors

### 1. Find an object from memory

- use `memory.query_object("cup")` in code execution
- read `target_pose` from result
- hand off `target_pose` to navigation or manipulation

### 2. Navigate to a remembered place

- use `memory.query_place("厨房")` in code execution
- read `target_pose` from result
- call `env.navigate_to(x=..., y=..., theta=...)` with the pose

### 3. Recall a semantic scene from description

- query via `memory` object with semantic text
- inspect evidence and target pose
- optionally move robot to re-observe the scene

### 4. Build memory from current camera view

- get camera frame from `env` in code execution
- add note/tags or detections
- call `memory.upsert_object(...)` or `memory.upsert_place(...)`

### 5. Build memory offline from videos or patrol logs

- create a task with `/pipeline/tasks`
- poll `/pipeline/tasks/{task_id}`
- validate retrievability with query endpoints

## Responsibility Boundary

This skill owns:

- when to query memory
- which memory endpoint to use
- how memory results map to navigation or manipulation targets
- how live robot camera frames can become memory inputs

This skill does not own full robot SDK discovery. Use `abotclaw-sdk-discovery` for that.

## Navigation Handoff Rule

When memory returns a `target_pose`, treat that as a candidate navigation/manipulation goal, not guaranteed truth. Check confidence and evidence before executing risky actions.

## Storage Notes

- structured DB: `data/memory_hub.db`
- image evidence: `data/images/*.jpg`

## Behavioral Rule

A strong agent should combine:

- live robot perception,
- remembered spatial context,
- and explicit evidence from memory results.

Do not treat memory as magic. Treat it as a retrievable, inspectable world model.
