#!/usr/bin/env python3
"""Auto-generated code execution wrapper for Unitree G1.

Architecture:
  - Runs under /usr/bin/python3
  - ``env``：``G1RobotEnv.from_config()``（对齐 Piper 读 ``robot_sdk/config.yaml``）
  - 另有 camera / yolo 等兼容别名；地址见 ``g1`` 配置而非本文件
"""

import sys

sys.path.insert(0, "/home/unitree/abotclaw_nv/robot_client/unitree_G1/agent_server")
sys.path.insert(0, "/home/unitree/abotclaw_nv/robot_client/unitree_G1/agent_server/robot_sdk")

from robot_sdk.code_execute_bootstrap import (
    install_executor_runtime,
    print_exec_result_if_any,
    shutdown_executor_runtime,
)

install_executor_runtime(globals())

# ============================================================================
# USER CODE STARTS HERE (auto-formatted with Black when possible)
# ============================================================================

result = None

from geometry_msgs.msg import PoseStamped
import json

nav = Nav2Anywhere()
pose = nav.get_current_pose()

if pose is None:
    print("ERROR: TF map->body not ready, pose is None")
else:
    p = pose.pose.position
    o = pose.pose.orientation
    result = {
        "x": p.x,
        "y": p.y,
        "z": p.z,
        "qx": o.x,
        "qy": o.y,
        "qz": o.z,
        "qw": o.w,
        "frame_id": pose.header.frame_id,
    }
    print(json.dumps(result, indent=2))


# ============================================================================
# USER CODE ENDS HERE
# ============================================================================

print_exec_result_if_any()
shutdown_executor_runtime()
