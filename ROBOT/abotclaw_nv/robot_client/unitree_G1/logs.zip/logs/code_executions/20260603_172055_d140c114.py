#!/usr/bin/env python3
"""Auto-generated code execution wrapper for Unitree G1.

Architecture:
  - Runs under /usr/bin/python3
  - ``env``：``G1RobotEnv.from_config()``（对齐 Piper 读 ``robot_sdk/config.yaml``）
  - 另有 camera / yolo 等兼容别名；地址见 ``g1`` 配置而非本文件
"""

import sys

sys.path.insert(0, "/home/unitree/abotclaw_nv/robot_client/unitree_G1/agent_server")
sys.path.insert(0, "/home/unitree/abotclaw_nv/robot_client/unitree_G1/agent_server/robot_sdk")

from robot_sdk.code_execute_bootstrap import (
    install_executor_runtime,
    print_exec_result_if_any,
    shutdown_executor_runtime,
)

install_executor_runtime(globals())

# ============================================================================
# USER CODE STARTS HERE (auto-formatted with Black when possible)
# ============================================================================

result = None

import time

# 1. 先用 D435i 检测环境（朝下视角，看桌面）
print("检测桌面物体...")
detections = yolo.detect_env()
print(f"检测到: {detections}")

# 2. 抓取瓶子（一体化：检测+抓取）
print("开始抓取瓶子...")
success = grasp_something("bottle")
print(f"抓取结果: {success}")

# 3. TTS 播报结果
tts.initialize()
if success:
    tts.speak("瓶子抓取成功")
    print("TTS: 瓶子抓取成功")
else:
    tts.speak("瓶子抓取失败")
    print("TTS: 瓶子抓取失败")

print("Done")


# ============================================================================
# USER CODE ENDS HERE
# ============================================================================

print_exec_result_if_any()
shutdown_executor_runtime()
