#!/usr/bin/env python3
"""Auto-generated code execution wrapper for Unitree G1.

Architecture:
  - Runs under /usr/bin/python3
  - ``env``：``G1RobotEnv.from_config()``（对齐 Piper 读 ``robot_sdk/config.yaml``）
  - 另有 camera / yolo 等兼容别名；地址见 ``g1`` 配置而非本文件
"""

import sys

sys.path.insert(0, "/home/unitree/abotclaw_nv/robot_client/unitree_G1/agent_server")
sys.path.insert(0, "/home/unitree/abotclaw_nv/robot_client/unitree_G1/agent_server/robot_sdk")

from robot_sdk.code_execute_bootstrap import (
    install_executor_runtime,
    print_exec_result_if_any,
    shutdown_executor_runtime,
)

install_executor_runtime(globals())

# ============================================================================
# USER CODE STARTS HERE (auto-formatted with Black when possible)
# ============================================================================

result = None

from geometry_msgs.msg import PoseStamped
import json

# 1. 获取当前位姿
nav = Nav2Anywhere()
current_pose = nav.get_current_pose()

if current_pose is None:
    print("ERROR: TF map->body 未就绪，无法获取当前位姿")
else:
    pos = current_pose.pose.position
    ori = current_pose.pose.orientation
    print(f"Current pose: x={pos.x:.4f}, y={pos.y:.4f}, z={pos.z:.4f}")
    print(
        f"Orientation: qx={ori.x:.4f}, qy={ori.y:.4f}, qz={ori.z:.4f}, qw={ori.w:.4f}"
    )

    # 2. 写入空间记忆
    result = memory.upsert_place(
        place_name="客厅",
        robot_id="g1_001",
        robot_type="humanoid",
        place_pose={
            "x": pos.x,
            "y": pos.y,
            "z": pos.z,
            "qx": ori.x,
            "qy": ori.y,
            "qz": ori.z,
            "qw": ori.w,
            "frame_id": "map",
        },
    )
    print(f"Memory upsert result: {result}")
    print("客厅 已记录")


# ============================================================================
# USER CODE ENDS HERE
# ============================================================================

print_exec_result_if_any()
shutdown_executor_runtime()
