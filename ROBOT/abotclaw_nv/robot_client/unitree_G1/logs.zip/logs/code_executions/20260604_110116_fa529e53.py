#!/usr/bin/env python3
"""Auto-generated code execution wrapper for Unitree G1.

Architecture:
  - Runs under /usr/bin/python3
  - ``env``：``G1RobotEnv.from_config()``（对齐 Piper 读 ``robot_sdk/config.yaml``）
  - 另有 camera / yolo 等兼容别名；地址见 ``g1`` 配置而非本文件
"""

import sys

sys.path.insert(0, "/home/unitree/abotclaw_nv/robot_client/unitree_G1/agent_server")
sys.path.insert(0, "/home/unitree/abotclaw_nv/robot_client/unitree_G1/agent_server/robot_sdk")

from robot_sdk.code_execute_bootstrap import (
    install_executor_runtime,
    print_exec_result_if_any,
    shutdown_executor_runtime,
)

install_executor_runtime(globals())

# ============================================================================
# USER CODE STARTS HERE (auto-formatted with Black when possible)
# ============================================================================

result = None

import cv2
import numpy as np
import time
import os

# 获取 D455 当前画面
rgb, depth = camera.get_frame()
print("D455 画面获取成功")
print("RGB shape: " + str(rgb.shape))

# 保存 RGB 图像到 /tmp（机器人本地可写目录）
img_path = "/tmp/d455_keyframe_test.jpg"
cv2.imwrite(img_path, cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR))
print("RGB 图像已保存: " + img_path)

# 验证文件是否存在
import os

if os.path.exists(img_path):
    print("文件确认存在，大小: " + str(os.path.getsize(img_path)) + " bytes")
else:
    print("文件保存失败")


# ============================================================================
# USER CODE ENDS HERE
# ============================================================================

print_exec_result_if_any()
shutdown_executor_runtime()
