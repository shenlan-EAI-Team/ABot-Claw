#!/usr/bin/env python3
"""Auto-generated code execution wrapper for Unitree G1.

Architecture:
  - Runs under /usr/bin/python3
  - ``env``：``G1RobotEnv.from_config()``（对齐 Piper 读 ``robot_sdk/config.yaml``）
  - 另有 camera / yolo 等兼容别名；地址见 ``g1`` 配置而非本文件
"""

import sys

sys.path.insert(0, "/home/unitree/abotclaw_nv/robot_client/unitree_G1/agent_server")
sys.path.insert(0, "/home/unitree/abotclaw_nv/robot_client/unitree_G1/agent_server/robot_sdk")

from robot_sdk.code_execute_bootstrap import (
    install_executor_runtime,
    print_exec_result_if_any,
    shutdown_executor_runtime,
)

install_executor_runtime(globals())

# ============================================================================
# USER CODE STARTS HERE (auto-formatted with Black when possible)
# ============================================================================

result = None

import cv2
import numpy as np

# 检查 D455
try:
    rgb, depth = camera.get_frame()
    d455_ok = rgb is not None and depth is not None
    d455_info = f"RGB={rgb.shape}, Depth={depth.shape}" if d455_ok else "获取失败"
except Exception as e:
    d455_ok = False
    d455_info = str(e)

# 检查 D435i
try:
    rgb2, depth2 = camera_d435i.get_frame()
    d435i_ok = rgb2 is not None and depth2 is not None
    d435i_info = f"RGB={rgb2.shape}, Depth={depth2.shape}" if d435i_ok else "获取失败"
except Exception as e:
    d435i_ok = False
    d435i_info = str(e)

print(f"D455: {OK if d455_ok else FAIL} | {d455_info}")
print(f"D435i: {OK if d435i_ok else FAIL} | {d435i_info}")


# ============================================================================
# USER CODE ENDS HERE
# ============================================================================

print_exec_result_if_any()
shutdown_executor_runtime()
