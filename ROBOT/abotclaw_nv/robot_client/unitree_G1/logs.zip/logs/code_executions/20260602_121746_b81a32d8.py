#!/usr/bin/env python3
"""Auto-generated code execution wrapper for Unitree G1.

Architecture:
  - Runs under /usr/bin/python3
  - ``env``：``G1RobotEnv.from_config()``（对齐 Piper 读 ``robot_sdk/config.yaml``）
  - 另有 camera / yolo 等兼容别名；地址见 ``g1`` 配置而非本文件
"""

import sys

sys.path.insert(0, "/home/unitree/abotclaw_nv/robot_client/unitree_G1/agent_server")
sys.path.insert(0, "/home/unitree/abotclaw_nv/robot_client/unitree_G1/agent_server/robot_sdk")

from robot_sdk.code_execute_bootstrap import (
    install_executor_runtime,
    print_exec_result_if_any,
    shutdown_executor_runtime,
)

install_executor_runtime(globals())

# ============================================================================
# USER CODE STARTS HERE (auto-formatted with Black when possible)
# ============================================================================

result = None

import json

# 1. 人脸识别（D455 水平朝前相机）
face_result = face.recognize_current_frame()
print("[FACE_RESULT]", json.dumps(face_result, ensure_ascii=False))

# 2. 提取人名
name = "朋友"
if face_result and "results" in face_result:
    results = face_result["results"]
    if len(results) > 0:
        best = max(results, key=lambda r: r.get("confidence", 0))
        detected_name = best.get("name", "")
        if detected_name and detected_name != "unknown":
            name = detected_name

print("[DETECTED_NAME]", name)

# 3. TTS 欢迎
welcome_msg = f"欢迎{name}来深蓝学院"
print("[TTS_MSG]", welcome_msg)

tts.initialize()
tts.speak(welcome_msg)
tts.close()


# ============================================================================
# USER CODE ENDS HERE
# ============================================================================

print_exec_result_if_any()
shutdown_executor_runtime()
