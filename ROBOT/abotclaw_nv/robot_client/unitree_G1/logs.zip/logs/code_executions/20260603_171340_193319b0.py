#!/usr/bin/env python3
"""Auto-generated code execution wrapper for Unitree G1.

Architecture:
  - Runs under /usr/bin/python3
  - ``env``：``G1RobotEnv.from_config()``（对齐 Piper 读 ``robot_sdk/config.yaml``）
  - 另有 camera / yolo 等兼容别名；地址见 ``g1`` 配置而非本文件
"""

import sys

sys.path.insert(0, "/home/unitree/abotclaw_nv/robot_client/unitree_G1/agent_server")
sys.path.insert(0, "/home/unitree/abotclaw_nv/robot_client/unitree_G1/agent_server/robot_sdk")

from robot_sdk.code_execute_bootstrap import (
    install_executor_runtime,
    print_exec_result_if_any,
    shutdown_executor_runtime,
)

install_executor_runtime(globals())

# ============================================================================
# USER CODE STARTS HERE (auto-formatted with Black when possible)
# ============================================================================

result = None

from geometry_msgs.msg import PoseStamped
import json

# 1. 从空间记忆查询客厅坐标
place_result = memory.query_place("客厅")
print(f"Query result type: {type(place_result)}")
print(f"Query result: {place_result}")

# query_place 返回列表，取第一个结果
target = None
if isinstance(place_result, list) and len(place_result) > 0:
    target = place_result[0].get("target_pose")
elif isinstance(place_result, dict) and "target_pose" in place_result:
    target = place_result["target_pose"]

if target is None:
    print("ERROR: 未找到客厅导航点")
else:
    print(f"Target pose: x={target['x']:.4f}, y={target['y']:.4f}, z={target['z']:.4f}")
    print(
        f"Orientation: qx={target['qx']:.4f}, qy={target['qy']:.4f}, qz={target['qz']:.4f}, qw={target['qw']:.4f}"
    )

    # 2. 构造 PoseStamped（必须包含完整朝向）
    pose = PoseStamped()
    pose.header.frame_id = "map"
    pose.pose.position.x = target["x"]
    pose.pose.position.y = target["y"]
    pose.pose.position.z = target["z"]
    pose.pose.orientation.x = target["qx"]
    pose.pose.orientation.y = target["qy"]
    pose.pose.orientation.z = target["qz"]
    pose.pose.orientation.w = target["qw"]

    # 3. 导航到目标点
    nav = Nav2Anywhere()
    nav.nav_to_pose(pose)

    # 4. 等待到达
    reached = nav.wait_until_reached(timeout_sec=60)
    if reached:
        print("已到达客厅")
        tts.initialize()
        tts.speak("已到达客厅")
    else:
        print("导航超时，可能未到达客厅")
        tts.initialize()
        tts.speak("导航超时")


# ============================================================================
# USER CODE ENDS HERE
# ============================================================================

print_exec_result_if_any()
shutdown_executor_runtime()
