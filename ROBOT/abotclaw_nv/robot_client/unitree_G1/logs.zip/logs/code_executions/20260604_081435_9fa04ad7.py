#!/usr/bin/env python3
"""Auto-generated code execution wrapper for Unitree G1.

Architecture:
  - Runs under /usr/bin/python3
  - ``env``：``G1RobotEnv.from_config()``（对齐 Piper 读 ``robot_sdk/config.yaml``）
  - 另有 camera / yolo 等兼容别名；地址见 ``g1`` 配置而非本文件
"""

import sys

sys.path.insert(0, "/home/unitree/abotclaw_nv/robot_client/unitree_G1/agent_server")
sys.path.insert(0, "/home/unitree/abotclaw_nv/robot_client/unitree_G1/agent_server/robot_sdk")

from robot_sdk.code_execute_bootstrap import (
    install_executor_runtime,
    print_exec_result_if_any,
    shutdown_executor_runtime,
)

install_executor_runtime(globals())

# ============================================================================
# USER CODE STARTS HERE (auto-formatted with Black when possible)
# ============================================================================

result = None

import json

# Recognize faces using D455 (head camera)
result = face.recognize_current_frame()
print("Face recognition result:")
print(json.dumps(result, indent=2, ensure_ascii=False))

# Check if 褀馨 is detected
found_qixin = False
if "results" in result:
    for person in result["results"]:
        name = person.get("name", "")
        print(f'Detected: {name} (confidence: {person.get("confidence", 0)})')
        if name == "褀馨":
            found_qixin = True
            break

if found_qixin:
    print("Found 褀馨! Playing greeting...")
    tts.initialize()
    tts.speak("你好褀馨，欢迎回来")
    print("Greeting played")
else:
    print("褀馨 not detected in current frame")


# ============================================================================
# USER CODE ENDS HERE
# ============================================================================

print_exec_result_if_any()
shutdown_executor_runtime()
