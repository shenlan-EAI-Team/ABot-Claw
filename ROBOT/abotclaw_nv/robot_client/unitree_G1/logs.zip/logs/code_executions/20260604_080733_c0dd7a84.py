#!/usr/bin/env python3
"""Auto-generated code execution wrapper for Unitree G1.

Architecture:
  - Runs under /usr/bin/python3
  - ``env``：``G1RobotEnv.from_config()``（对齐 Piper 读 ``robot_sdk/config.yaml``）
  - 另有 camera / yolo 等兼容别名；地址见 ``g1`` 配置而非本文件
"""

import sys

sys.path.insert(0, "/home/unitree/abotclaw_nv/robot_client/unitree_G1/agent_server")
sys.path.insert(0, "/home/unitree/abotclaw_nv/robot_client/unitree_G1/agent_server/robot_sdk")

from robot_sdk.code_execute_bootstrap import (
    install_executor_runtime,
    print_exec_result_if_any,
    shutdown_executor_runtime,
)

install_executor_runtime(globals())

# ============================================================================
# USER CODE STARTS HERE (auto-formatted with Black when possible)
# ============================================================================

result = None

import cv2
import numpy as np

print("=== D455 (head camera) ===")
try:
    rgb, depth = camera.get_frame()
    print(f"RGB shape: {rgb.shape}, dtype: {rgb.dtype}")
    print(f"Depth shape: {depth.shape}, dtype: {depth.dtype}")
    print(f"Depth range: [{depth.min():.3f}, {depth.max():.3f}] m")
    cv2.imwrite(
        "/home/slxy/.openclaw/workspace/d455_rgb.jpg",
        cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR),
    )
    print("Saved: d455_rgb.jpg")
except Exception as e:
    print(f"D455 ERROR: {e}")

print()

print("=== D435i (gripper camera) ===")
try:
    rgb2, depth2 = camera_d435i.get_frame()
    print(f"RGB shape: {rgb2.shape}, dtype: {rgb2.dtype}")
    print(f"Depth shape: {depth2.shape}, dtype: {depth2.dtype}")
    print(f"Depth range: [{depth2.min():.3f}, {depth2.max():.3f}] m")
    cv2.imwrite(
        "/home/slxy/.openclaw/workspace/d435i_rgb.jpg",
        cv2.cvtColor(rgb2, cv2.COLOR_RGB2BGR),
    )
    print("Saved: d435i_rgb.jpg")
except Exception as e:
    print(f"D435i ERROR: {e}")


# ============================================================================
# USER CODE ENDS HERE
# ============================================================================

print_exec_result_if_any()
shutdown_executor_runtime()
