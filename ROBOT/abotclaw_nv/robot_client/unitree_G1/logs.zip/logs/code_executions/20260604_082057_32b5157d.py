#!/usr/bin/env python3
"""Auto-generated code execution wrapper for Unitree G1.

Architecture:
  - Runs under /usr/bin/python3
  - ``env``：``G1RobotEnv.from_config()``（对齐 Piper 读 ``robot_sdk/config.yaml``）
  - 另有 camera / yolo 等兼容别名；地址见 ``g1`` 配置而非本文件
"""

import sys

sys.path.insert(0, "/home/unitree/abotclaw_nv/robot_client/unitree_G1/agent_server")
sys.path.insert(0, "/home/unitree/abotclaw_nv/robot_client/unitree_G1/agent_server/robot_sdk")

from robot_sdk.code_execute_bootstrap import (
    install_executor_runtime,
    print_exec_result_if_any,
    shutdown_executor_runtime,
)

install_executor_runtime(globals())

# ============================================================================
# USER CODE STARTS HERE (auto-formatted with Black when possible)
# ============================================================================

result = None

import json
import time

print("Starting continuous face detection for 褀馨...")
print("Will keep trying until detected. Press Ctrl+C to stop.")

attempt = 0
found = False

while not found:
    attempt += 1
    result = face.recognize_current_frame()
    count = result.get("count", 0)

    if count > 0:
        print(f"[Attempt {attempt}] Detected {count} face(s)")
        for person in result.get("results", []):
            name = person.get("name", "unknown")
            conf = person.get("confidence", 0)
            print(f"  - {name} (confidence: {conf:.3f})")
            if name == "褀馨":
                print("✓ Found 褀馨! Playing greeting...")
                tts.initialize()
                tts.speak("你好褀馨，欢迎回来")
                print("Greeting played successfully")
                found = True
                break
    else:
        if attempt % 10 == 0:
            print(f"[Attempt {attempt}] No faces detected yet...")

    time.sleep(1)

print("Detection loop ended.")


# ============================================================================
# USER CODE ENDS HERE
# ============================================================================

print_exec_result_if_any()
shutdown_executor_runtime()
