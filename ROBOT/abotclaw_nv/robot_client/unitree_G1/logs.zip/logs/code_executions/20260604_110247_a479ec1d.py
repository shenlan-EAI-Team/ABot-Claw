#!/usr/bin/env python3
"""Auto-generated code execution wrapper for Unitree G1.

Architecture:
  - Runs under /usr/bin/python3
  - ``env``：``G1RobotEnv.from_config()``（对齐 Piper 读 ``robot_sdk/config.yaml``）
  - 另有 camera / yolo 等兼容别名；地址见 ``g1`` 配置而非本文件
"""

import sys

sys.path.insert(0, "/home/unitree/abotclaw_nv/robot_client/unitree_G1/agent_server")
sys.path.insert(0, "/home/unitree/abotclaw_nv/robot_client/unitree_G1/agent_server/robot_sdk")

from robot_sdk.code_execute_bootstrap import (
    install_executor_runtime,
    print_exec_result_if_any,
    shutdown_executor_runtime,
)

install_executor_runtime(globals())

# ============================================================================
# USER CODE STARTS HERE (auto-formatted with Black when possible)
# ============================================================================

result = None

import cv2
import numpy as np
import time
import os
import base64

# 获取 D455 当前画面
rgb, depth = camera.get_frame()
print("D455 画面获取成功")
print("RGB shape: " + str(rgb.shape))

# 保存 RGB 图像到 /tmp
img_path = "/tmp/d455_keyframe_test.jpg"
cv2.imwrite(img_path, cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR))
print("RGB 图像已保存: " + img_path)

# 读取并 base64 编码
with open(img_path, "rb") as f:
    img_bytes = f.read()
    img_b64 = base64.b64encode(img_bytes).decode("utf-8")
print("Base64 编码完成，长度: " + str(len(img_b64)))

# 输出 base64 字符串到 stdout，供外部 curl 使用
print("\n---BASE64_START---")
print(img_b64)
print("---BASE64_END---")

print("\n任务完成")


# ============================================================================
# USER CODE ENDS HERE
# ============================================================================

print_exec_result_if_any()
shutdown_executor_runtime()
