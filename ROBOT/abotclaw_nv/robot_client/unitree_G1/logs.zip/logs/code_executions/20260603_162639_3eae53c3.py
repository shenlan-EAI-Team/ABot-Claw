#!/usr/bin/env python3
"""Auto-generated code execution wrapper for Unitree G1.

Architecture:
  - Runs under /usr/bin/python3
  - ``env``：``G1RobotEnv.from_config()``（对齐 Piper 读 ``robot_sdk/config.yaml``）
  - 另有 camera / yolo 等兼容别名；地址见 ``g1`` 配置而非本文件
"""

import sys

sys.path.insert(0, "/home/unitree/abotclaw_nv/robot_client/unitree_G1/agent_server")
sys.path.insert(0, "/home/unitree/abotclaw_nv/robot_client/unitree_G1/agent_server/robot_sdk")

from robot_sdk.code_execute_bootstrap import (
    install_executor_runtime,
    print_exec_result_if_any,
    shutdown_executor_runtime,
)

install_executor_runtime(globals())

# ============================================================================
# USER CODE STARTS HERE (auto-formatted with Black when possible)
# ============================================================================

result = None

import time

# 1. 读取相机画面 (D455 水平朝前)
rgb, depth = camera.get_frame()
print("Camera frame captured")

# 2. 人脸识别
result = face.recognize_current_frame()
print("Face recognition result:", result)

# 3. 检查结果，如果看到张三就说话
found_zhangsan = False
if result and "results" in result:
    for person in result["results"]:
        name = person.get("name", "unknown")
        conf = person.get("confidence", 0)
        print(f"Detected: {name}, confidence: {conf:.3f}")
        if name == "张三":
            found_zhangsan = True

# 4. TTS
tts.initialize()
if found_zhangsan:
    tts.speak("你好张三，欢迎回来")
    print("TTS: 你好张三，欢迎回来")
else:
    tts.speak("没有识别到张三")
    print("TTS: 没有识别到张三")

print("Done")


# ============================================================================
# USER CODE ENDS HERE
# ============================================================================

print_exec_result_if_any()
shutdown_executor_runtime()
