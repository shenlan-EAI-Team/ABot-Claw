#!/usr/bin/env python3
"""Auto-generated code execution wrapper for Unitree G1.

Architecture:
  - Runs under /usr/bin/python3
  - ``env``：``G1RobotEnv.from_config()``（对齐 Piper 读 ``robot_sdk/config.yaml``）
  - 另有 camera / yolo 等兼容别名；地址见 ``g1`` 配置而非本文件
"""

import sys

sys.path.insert(0, "/home/unitree/abotclaw_nv/robot_client/unitree_G1/agent_server")
sys.path.insert(0, "/home/unitree/abotclaw_nv/robot_client/unitree_G1/agent_server/robot_sdk")

from robot_sdk.code_execute_bootstrap import (
    install_executor_runtime,
    print_exec_result_if_any,
    shutdown_executor_runtime,
)

install_executor_runtime(globals())

# ============================================================================
# USER CODE STARTS HERE (auto-formatted with Black when possible)
# ============================================================================

result = None

import json

# 尝试获取 Face SDK 的注册人员列表
# face 对象可能没有直接列出所有人员的方法，尝试通过属性查看
print("[FACE_TYPE]", type(face).__name__)
print("[FACE_DIR]", [attr for attr in dir(face) if not attr.startswith("_")])

# 尝试调用可能的方法
try:
    # 有些实现可能有 list_persons 或 get_persons 方法
    if hasattr(face, "list_persons"):
        persons = face.list_persons()
        print("[PERSONS]", json.dumps(persons, ensure_ascii=False))
    elif hasattr(face, "get_persons"):
        persons = face.get_persons()
        print("[PERSONS]", json.dumps(persons, ensure_ascii=False))
    elif hasattr(face, "persons"):
        print("[PERSONS]", json.dumps(face.persons, ensure_ascii=False))
    else:
        print("[INFO] face 对象没有直接列出人员的方法")
        # 尝试查看 face 的内部属性
        print(
            "[FACE_ATTRS]",
            {
                k: str(type(v).__name__)
                for k, v in face.__dict__.items()
                if not k.startswith("_")
            },
        )
except Exception as e:
    print("[ERROR]", str(e))


# ============================================================================
# USER CODE ENDS HERE
# ============================================================================

print_exec_result_if_any()
shutdown_executor_runtime()
